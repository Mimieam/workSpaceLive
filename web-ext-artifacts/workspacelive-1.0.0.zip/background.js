/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/.pnpm/lz-string@1.5.0/node_modules/lz-string/libs/lz-string.js":
/*!*************************************************************************************!*\
  !*** ./node_modules/.pnpm/lz-string@1.5.0/node_modules/lz-string/libs/lz-string.js ***!
  \*************************************************************************************/
/***/ ((module, exports, __webpack_require__) => {

var __WEBPACK_AMD_DEFINE_RESULT__;// Copyright (c) 2013 Pieroxy <pieroxy@pieroxy.net>
// This work is free. You can redistribute it and/or modify it
// under the terms of the WTFPL, Version 2
// For more information see LICENSE.txt or http://www.wtfpl.net/
//
// For more information, the home page:
// http://pieroxy.net/blog/pages/lz-string/testing.html
//
// LZ-based compression algorithm, version 1.4.5
var LZString = (function() {

// private property
var f = String.fromCharCode;
var keyStrBase64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
var keyStrUriSafe = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$";
var baseReverseDic = {};

function getBaseValue(alphabet, character) {
  if (!baseReverseDic[alphabet]) {
    baseReverseDic[alphabet] = {};
    for (var i=0 ; i<alphabet.length ; i++) {
      baseReverseDic[alphabet][alphabet.charAt(i)] = i;
    }
  }
  return baseReverseDic[alphabet][character];
}

var LZString = {
  compressToBase64 : function (input) {
    if (input == null) return "";
    var res = LZString._compress(input, 6, function(a){return keyStrBase64.charAt(a);});
    switch (res.length % 4) { // To produce valid Base64
    default: // When could this happen ?
    case 0 : return res;
    case 1 : return res+"===";
    case 2 : return res+"==";
    case 3 : return res+"=";
    }
  },

  decompressFromBase64 : function (input) {
    if (input == null) return "";
    if (input == "") return null;
    return LZString._decompress(input.length, 32, function(index) { return getBaseValue(keyStrBase64, input.charAt(index)); });
  },

  compressToUTF16 : function (input) {
    if (input == null) return "";
    return LZString._compress(input, 15, function(a){return f(a+32);}) + " ";
  },

  decompressFromUTF16: function (compressed) {
    if (compressed == null) return "";
    if (compressed == "") return null;
    return LZString._decompress(compressed.length, 16384, function(index) { return compressed.charCodeAt(index) - 32; });
  },

  //compress into uint8array (UCS-2 big endian format)
  compressToUint8Array: function (uncompressed) {
    var compressed = LZString.compress(uncompressed);
    var buf=new Uint8Array(compressed.length*2); // 2 bytes per character

    for (var i=0, TotalLen=compressed.length; i<TotalLen; i++) {
      var current_value = compressed.charCodeAt(i);
      buf[i*2] = current_value >>> 8;
      buf[i*2+1] = current_value % 256;
    }
    return buf;
  },

  //decompress from uint8array (UCS-2 big endian format)
  decompressFromUint8Array:function (compressed) {
    if (compressed===null || compressed===undefined){
        return LZString.decompress(compressed);
    } else {
        var buf=new Array(compressed.length/2); // 2 bytes per character
        for (var i=0, TotalLen=buf.length; i<TotalLen; i++) {
          buf[i]=compressed[i*2]*256+compressed[i*2+1];
        }

        var result = [];
        buf.forEach(function (c) {
          result.push(f(c));
        });
        return LZString.decompress(result.join(''));

    }

  },


  //compress into a string that is already URI encoded
  compressToEncodedURIComponent: function (input) {
    if (input == null) return "";
    return LZString._compress(input, 6, function(a){return keyStrUriSafe.charAt(a);});
  },

  //decompress from an output of compressToEncodedURIComponent
  decompressFromEncodedURIComponent:function (input) {
    if (input == null) return "";
    if (input == "") return null;
    input = input.replace(/ /g, "+");
    return LZString._decompress(input.length, 32, function(index) { return getBaseValue(keyStrUriSafe, input.charAt(index)); });
  },

  compress: function (uncompressed) {
    return LZString._compress(uncompressed, 16, function(a){return f(a);});
  },
  _compress: function (uncompressed, bitsPerChar, getCharFromInt) {
    if (uncompressed == null) return "";
    var i, value,
        context_dictionary= {},
        context_dictionaryToCreate= {},
        context_c="",
        context_wc="",
        context_w="",
        context_enlargeIn= 2, // Compensate for the first entry which should not count
        context_dictSize= 3,
        context_numBits= 2,
        context_data=[],
        context_data_val=0,
        context_data_position=0,
        ii;

    for (ii = 0; ii < uncompressed.length; ii += 1) {
      context_c = uncompressed.charAt(ii);
      if (!Object.prototype.hasOwnProperty.call(context_dictionary,context_c)) {
        context_dictionary[context_c] = context_dictSize++;
        context_dictionaryToCreate[context_c] = true;
      }

      context_wc = context_w + context_c;
      if (Object.prototype.hasOwnProperty.call(context_dictionary,context_wc)) {
        context_w = context_wc;
      } else {
        if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate,context_w)) {
          if (context_w.charCodeAt(0)<256) {
            for (i=0 ; i<context_numBits ; i++) {
              context_data_val = (context_data_val << 1);
              if (context_data_position == bitsPerChar-1) {
                context_data_position = 0;
                context_data.push(getCharFromInt(context_data_val));
                context_data_val = 0;
              } else {
                context_data_position++;
              }
            }
            value = context_w.charCodeAt(0);
            for (i=0 ; i<8 ; i++) {
              context_data_val = (context_data_val << 1) | (value&1);
              if (context_data_position == bitsPerChar-1) {
                context_data_position = 0;
                context_data.push(getCharFromInt(context_data_val));
                context_data_val = 0;
              } else {
                context_data_position++;
              }
              value = value >> 1;
            }
          } else {
            value = 1;
            for (i=0 ; i<context_numBits ; i++) {
              context_data_val = (context_data_val << 1) | value;
              if (context_data_position ==bitsPerChar-1) {
                context_data_position = 0;
                context_data.push(getCharFromInt(context_data_val));
                context_data_val = 0;
              } else {
                context_data_position++;
              }
              value = 0;
            }
            value = context_w.charCodeAt(0);
            for (i=0 ; i<16 ; i++) {
              context_data_val = (context_data_val << 1) | (value&1);
              if (context_data_position == bitsPerChar-1) {
                context_data_position = 0;
                context_data.push(getCharFromInt(context_data_val));
                context_data_val = 0;
              } else {
                context_data_position++;
              }
              value = value >> 1;
            }
          }
          context_enlargeIn--;
          if (context_enlargeIn == 0) {
            context_enlargeIn = Math.pow(2, context_numBits);
            context_numBits++;
          }
          delete context_dictionaryToCreate[context_w];
        } else {
          value = context_dictionary[context_w];
          for (i=0 ; i<context_numBits ; i++) {
            context_data_val = (context_data_val << 1) | (value&1);
            if (context_data_position == bitsPerChar-1) {
              context_data_position = 0;
              context_data.push(getCharFromInt(context_data_val));
              context_data_val = 0;
            } else {
              context_data_position++;
            }
            value = value >> 1;
          }


        }
        context_enlargeIn--;
        if (context_enlargeIn == 0) {
          context_enlargeIn = Math.pow(2, context_numBits);
          context_numBits++;
        }
        // Add wc to the dictionary.
        context_dictionary[context_wc] = context_dictSize++;
        context_w = String(context_c);
      }
    }

    // Output the code for w.
    if (context_w !== "") {
      if (Object.prototype.hasOwnProperty.call(context_dictionaryToCreate,context_w)) {
        if (context_w.charCodeAt(0)<256) {
          for (i=0 ; i<context_numBits ; i++) {
            context_data_val = (context_data_val << 1);
            if (context_data_position == bitsPerChar-1) {
              context_data_position = 0;
              context_data.push(getCharFromInt(context_data_val));
              context_data_val = 0;
            } else {
              context_data_position++;
            }
          }
          value = context_w.charCodeAt(0);
          for (i=0 ; i<8 ; i++) {
            context_data_val = (context_data_val << 1) | (value&1);
            if (context_data_position == bitsPerChar-1) {
              context_data_position = 0;
              context_data.push(getCharFromInt(context_data_val));
              context_data_val = 0;
            } else {
              context_data_position++;
            }
            value = value >> 1;
          }
        } else {
          value = 1;
          for (i=0 ; i<context_numBits ; i++) {
            context_data_val = (context_data_val << 1) | value;
            if (context_data_position == bitsPerChar-1) {
              context_data_position = 0;
              context_data.push(getCharFromInt(context_data_val));
              context_data_val = 0;
            } else {
              context_data_position++;
            }
            value = 0;
          }
          value = context_w.charCodeAt(0);
          for (i=0 ; i<16 ; i++) {
            context_data_val = (context_data_val << 1) | (value&1);
            if (context_data_position == bitsPerChar-1) {
              context_data_position = 0;
              context_data.push(getCharFromInt(context_data_val));
              context_data_val = 0;
            } else {
              context_data_position++;
            }
            value = value >> 1;
          }
        }
        context_enlargeIn--;
        if (context_enlargeIn == 0) {
          context_enlargeIn = Math.pow(2, context_numBits);
          context_numBits++;
        }
        delete context_dictionaryToCreate[context_w];
      } else {
        value = context_dictionary[context_w];
        for (i=0 ; i<context_numBits ; i++) {
          context_data_val = (context_data_val << 1) | (value&1);
          if (context_data_position == bitsPerChar-1) {
            context_data_position = 0;
            context_data.push(getCharFromInt(context_data_val));
            context_data_val = 0;
          } else {
            context_data_position++;
          }
          value = value >> 1;
        }


      }
      context_enlargeIn--;
      if (context_enlargeIn == 0) {
        context_enlargeIn = Math.pow(2, context_numBits);
        context_numBits++;
      }
    }

    // Mark the end of the stream
    value = 2;
    for (i=0 ; i<context_numBits ; i++) {
      context_data_val = (context_data_val << 1) | (value&1);
      if (context_data_position == bitsPerChar-1) {
        context_data_position = 0;
        context_data.push(getCharFromInt(context_data_val));
        context_data_val = 0;
      } else {
        context_data_position++;
      }
      value = value >> 1;
    }

    // Flush the last char
    while (true) {
      context_data_val = (context_data_val << 1);
      if (context_data_position == bitsPerChar-1) {
        context_data.push(getCharFromInt(context_data_val));
        break;
      }
      else context_data_position++;
    }
    return context_data.join('');
  },

  decompress: function (compressed) {
    if (compressed == null) return "";
    if (compressed == "") return null;
    return LZString._decompress(compressed.length, 32768, function(index) { return compressed.charCodeAt(index); });
  },

  _decompress: function (length, resetValue, getNextValue) {
    var dictionary = [],
        next,
        enlargeIn = 4,
        dictSize = 4,
        numBits = 3,
        entry = "",
        result = [],
        i,
        w,
        bits, resb, maxpower, power,
        c,
        data = {val:getNextValue(0), position:resetValue, index:1};

    for (i = 0; i < 3; i += 1) {
      dictionary[i] = i;
    }

    bits = 0;
    maxpower = Math.pow(2,2);
    power=1;
    while (power!=maxpower) {
      resb = data.val & data.position;
      data.position >>= 1;
      if (data.position == 0) {
        data.position = resetValue;
        data.val = getNextValue(data.index++);
      }
      bits |= (resb>0 ? 1 : 0) * power;
      power <<= 1;
    }

    switch (next = bits) {
      case 0:
          bits = 0;
          maxpower = Math.pow(2,8);
          power=1;
          while (power!=maxpower) {
            resb = data.val & data.position;
            data.position >>= 1;
            if (data.position == 0) {
              data.position = resetValue;
              data.val = getNextValue(data.index++);
            }
            bits |= (resb>0 ? 1 : 0) * power;
            power <<= 1;
          }
        c = f(bits);
        break;
      case 1:
          bits = 0;
          maxpower = Math.pow(2,16);
          power=1;
          while (power!=maxpower) {
            resb = data.val & data.position;
            data.position >>= 1;
            if (data.position == 0) {
              data.position = resetValue;
              data.val = getNextValue(data.index++);
            }
            bits |= (resb>0 ? 1 : 0) * power;
            power <<= 1;
          }
        c = f(bits);
        break;
      case 2:
        return "";
    }
    dictionary[3] = c;
    w = c;
    result.push(c);
    while (true) {
      if (data.index > length) {
        return "";
      }

      bits = 0;
      maxpower = Math.pow(2,numBits);
      power=1;
      while (power!=maxpower) {
        resb = data.val & data.position;
        data.position >>= 1;
        if (data.position == 0) {
          data.position = resetValue;
          data.val = getNextValue(data.index++);
        }
        bits |= (resb>0 ? 1 : 0) * power;
        power <<= 1;
      }

      switch (c = bits) {
        case 0:
          bits = 0;
          maxpower = Math.pow(2,8);
          power=1;
          while (power!=maxpower) {
            resb = data.val & data.position;
            data.position >>= 1;
            if (data.position == 0) {
              data.position = resetValue;
              data.val = getNextValue(data.index++);
            }
            bits |= (resb>0 ? 1 : 0) * power;
            power <<= 1;
          }

          dictionary[dictSize++] = f(bits);
          c = dictSize-1;
          enlargeIn--;
          break;
        case 1:
          bits = 0;
          maxpower = Math.pow(2,16);
          power=1;
          while (power!=maxpower) {
            resb = data.val & data.position;
            data.position >>= 1;
            if (data.position == 0) {
              data.position = resetValue;
              data.val = getNextValue(data.index++);
            }
            bits |= (resb>0 ? 1 : 0) * power;
            power <<= 1;
          }
          dictionary[dictSize++] = f(bits);
          c = dictSize-1;
          enlargeIn--;
          break;
        case 2:
          return result.join('');
      }

      if (enlargeIn == 0) {
        enlargeIn = Math.pow(2, numBits);
        numBits++;
      }

      if (dictionary[c]) {
        entry = dictionary[c];
      } else {
        if (c === dictSize) {
          entry = w + w.charAt(0);
        } else {
          return null;
        }
      }
      result.push(entry);

      // Add w+entry[0] to the dictionary.
      dictionary[dictSize++] = w + entry.charAt(0);
      enlargeIn--;

      w = entry;

      if (enlargeIn == 0) {
        enlargeIn = Math.pow(2, numBits);
        numBits++;
      }

    }
  }
};
  return LZString;
})();

if (true) {
  !(__WEBPACK_AMD_DEFINE_RESULT__ = (function () { return LZString; }).call(exports, __webpack_require__, exports, module),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
} else {}


/***/ }),

/***/ "./app/scripts/background.js":
/*!***********************************!*\
  !*** ./app/scripts/background.js ***!
  \***********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.10.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _libs_contextMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./libs/contextMenu */ "./app/scripts/libs/contextMenu.js");
/* harmony import */ var _libs_bgEvents__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./libs/bgEvents */ "./app/scripts/libs/bgEvents.js");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_libs_contextMenu__WEBPACK_IMPORTED_MODULE_1__]);
_libs_contextMenu__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// import { getOverlappingMonitor } from './libs/multiScreen';
// import { handleMessagePassing } from './libs/onMessageHook';


let DEBUG = true;
let OPENED_POPUP = [];
let __clipboardContent = '';
let portFromPOPUP;
// browser.runtime.onConnect.addListener(handleMessagePassing);
webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().runtime.onConnect.addListener((port)=>{
    portFromPOPUP = port;
    port.onMessage.addListener(async (request)=>{
        console.log(request);
        if (request.GET_POPUP_INFO) {
            console.log("GET_POPUP_INFO:  ", request.GET_POPUP_INFO, console.log(OPENED_POPUP));
            await portFromPOPUP.postMessage({
                POPUP_INFO: JSON.stringify(...OPENED_POPUP)
            });
        }
        // requests to background <==
        if (request.MOVE_TAB) {
            const data = request.MOVE_TAB;
            const [tabId, sI, wId, tIdx] = data.split(',').map((x)=>+x);
            if (wId) await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.move([
                tabId
            ], {
                windowId: wId,
                index: tIdx || -1
            });
            else await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.create({
                tabId: tabId
            });
            return;
        }
        if (request.TOGGLE_PIN) {
            const data = request.TOGGLE_PIN;
            const [tabId, ..._] = data.split(',').map((x)=>+x);
            webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.update(tabId, {
                pinned: !(await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.get(tabId))?.pinned
            });
            return;
        }
        if (request.BRING_FORWARD) {
            // console.log(request.BRING_FORWARD)
            const data = request.BRING_FORWARD;
            const [windowId, tabIndex] = data.split(',').map((x)=>+x);
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.update(windowId, {
                focused: true
            });
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.highlight({
                windowId: windowId,
                tabs: tabIndex
            });
            const lastID = (await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.getLastFocused())?.id;
            // console.log(`lastID = ${lastID}`)
            // console.log(`OPENED_POPUP =`, OPENED_POPUP)
            const { popupWindowId, parentId } = OPENED_POPUP[0];
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.update(popupWindowId, {
                focused: true
            });
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.highlight({
                windowId: popupWindowId,
                tabs: 0
            });
        // console.log(`popupWindowId = ${popupWindowId}`)
        }
        if (request.CLOSE_TAB) {
            const data = request.CLOSE_TAB;
            const [tabId, ..._] = data.split(',').map((x)=>+x);
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.remove([
                tabId
            ]);
        }
        if (request.CLOSE_WINDOW) {
            const windowId = request.CLOSE_WINDOW;
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.remove(windowId);
        }
    });
});
// handleMessagePassing()
chrome.action.onClicked.addListener(async ()=>{
    console.log('OPENING FROM BACKGROUND');
    // const currentMonitor = await getOverlappingMonitor()
    // SW doesn't have window so we need the screen using this... - might need to test with multiple Screen..
    const [{ workArea }] = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().system.display.getInfo();
    const currentMonitor = workArea;
    console.log(currentMonitor);
    const parentWindow = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.getCurrent();
    const parentConfig = {
        'width': parseInt(currentMonitor.width * (3 / 4)),
        'height': currentMonitor.height,
        // 'height': parseInt(currentMonitor.height * (4 / 5)),
        // 'height': parseInt(currentMonitor.height * (2 / 4)),
        'left': currentMonitor.left,
        'top': currentMonitor.top
    };
    const appConfig = {
        'width': currentMonitor.width - parentConfig.width,
        'height': parentConfig.height,
        'left': currentMonitor.left + parentConfig.width,
        'top': currentMonitor.top
    };
    if (OPENED_POPUP.length) {
        // console.log("OPENED_POPUP =")
        // console.log(OPENED_POPUP)
        const { popupWindowId, parentId } = OPENED_POPUP[0];
        let _parentId = parentWindow.id != parentId ? parentWindow.id : parentId;
        // console.log("_parentId = ",_parentId, popupWindowId)
        await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.update(popupWindowId, {
            focused: true
        });
        await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.highlight({
            windowId: popupWindowId,
            tabs: 0
        });
        //
        webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.update(popupWindowId, {
            drawAttention: true,
            ...appConfig
        }).then((w)=>console.log(w));
        webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.update(_parentId, {
            drawAttention: true,
            ...parentConfig
        }).then((w)=>console.log(w));
    } else {
        webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.create({
            'url': 'popup.html',
            'type': 'popup',
            ...appConfig
        }).then(async (appWindow)=>{
            console.log('POP UP CREATED', appWindow.id, appWindow);
            await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().windows.update(parentWindow.id, {
                ...parentConfig
            });
            // await browser.windows.update(parentWindow.id, { ...parentConfig }, (pW) => console.log(pW));
            OPENED_POPUP.push({
                popupWindowId: appWindow.id,
                popupTabId: appWindow.tabs[0].id,
                parentId: parentWindow.id
            });
            console.log("OPENED_POPUP =", OPENED_POPUP);
        });
    }
    portFromPOPUP?.postMessage({
        POPUP_INFO: JSON.stringify(...OPENED_POPUP)
    });
// chrome.developerPrivate.openDevTools({ extensionId: "nnlfihnjlcnpiddiilpmobjncpbhagnm" }, () => { console.log('DevTool Opened')})
});
chrome.windows.onRemoved.addListener((id)=>{
    console.log("closing window id = ", id);
    console.log(OPENED_POPUP);
    OPENED_POPUP = OPENED_POPUP.filter((x)=>x.popupWindowId != id);
    console.log("filtered after removed =", OPENED_POPUP);
});
/*
 * Chrome.action.setBadgeText({ text: `${displayText}` })
 * chrome.action.setBadgeBackgroundColor({ color: newColor });
 */ // document.addEventListener('copy', (e) => {
//     e.clipboardData.setData('text/plain', __clipboardContent);
//     e.preventDefault();
// });
const copyUrlsToClipboard = ()=>{};
const openUrls = async (_urls, windowId)=>{
    const openTabs = await _urls.map(async (_url, idx)=>{
        DEBUG && console.log(`opening : "${_url}"`);
        const t = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default().tabs.create({
            url: _url,
            windowId: windowId
        });
        console.log(t);
        return t;
    });
    return openTabs;
};
// browser.commands.onCommand.addListener(async (command) => {
//     const w = await browser.windows.getCurrent({ populate: true });
//     switch (command) {
//         case 'copy_all_url':
//             const text = w.tabs.flatMap(t => t.url).filter(x => x).join(',\n')
//             __clipboardContent = text
//             document.execCommand('copy')
//             console.log('Command:', command);
//             console.log(__clipboardContent)
//             break;
//         case 'open_copied_url':
//             const url = __clipboardContent.split(',\n')
//             console.log(url)
//             const res = openUrls(url, w.id)
//             console.log(res)
//             break;
//         default:
//             break;
//     }
// });
// /**
//  *  requires  permissions: - disabling this for now
// *   "<all_urls>",
//  *  "webRequest",
//     "webRequestBlocking",
//  * */
// browser.webRequest?.onBeforeRequest.addListener((req) => {
//     OPENED_POPUP.some(x => {
//         console.log(x.popupTabId,  req.tabId, x.popupTabId == req.tabId)
//         return x.popupTabId == req.tabId
//     })
//     if (OPENED_POPUP.some(x => x.popupTabId == req.tabId) && !req.url.includes('nnlfihnjlcnpiddiilpmobjncpbhagnm')) {
//         console.log("BLOCKED - ", req.url, req.tabId)
//         return {redirectUrl: 'chrome-extension://nnlfihnjlcnpiddiilpmobjncpbhagnm/popup.html'};
//         // return {cancel: true};
//     } 
// },{urls: ["<all_urls>"]},["blocking"])
const Rika = {
    browser: (webextension_polyfill__WEBPACK_IMPORTED_MODULE_0___default()),
    OPENED_POPUP
};
globalThis.Rika = Rika;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Rika);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ "./app/scripts/libs/bgEvents.js":
/*!**************************************!*\
  !*** ./app/scripts/libs/bgEvents.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./app/scripts/libs/utils.js");

/**
 * This function is called everytime a primary event is fired by the browser
 *
 * @param  ev   a chrome event
 */ const THRESHOLD = 500;
let start = Date.now();
const browserEventListener = async (e_name)=>{
    if (Date.now() - start > THRESHOLD) {
        _utils__WEBPACK_IMPORTED_MODULE_0__.ChromeRPC.sendMessage({
            cmd: "REFRESH_STATE"
        }, (response)=>{
            console.log(`[${e_name}] ev triggered [REFRESH_STATE] command. \n\t Output: `, response);
        });
        start = Date.now();
    }
};
chrome.windows.onCreated.addListener(()=>browserEventListener('windows.onCreated'));
chrome.windows.onRemoved.addListener(()=>browserEventListener('windows.onRemoved'));
chrome.tabs.onUpdated.addListener(()=>browserEventListener('tabs.onUpdated'));
chrome.tabs.onCreated.addListener(()=>browserEventListener('tabs.onCreated'));
chrome.tabs.onRemoved.addListener(()=>browserEventListener('tabs.onRemoved'));
chrome.tabs.onMoved.addListener(()=>browserEventListener('tabs.onMoved'));


/***/ }),

/***/ "./app/scripts/libs/contextMenu.js":
/*!*****************************************!*\
  !*** ./app/scripts/libs/contextMenu.js ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ctxMenu: () => (/* binding */ ctxMenu)
/* harmony export */ });
/* harmony import */ var _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./neoWorkSpace */ "./app/scripts/libs/neoWorkSpace.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.10.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./helpers */ "./app/scripts/libs/helpers.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils */ "./app/scripts/libs/utils.js");
/* harmony import */ var _offScreenUtils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./offScreenUtils */ "./app/scripts/libs/offScreenUtils.js");
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__]);
_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// thanks to https://stackoverflow.com/a/50936590/623546
/**
 * Dynamic ws context menu
 *
 */ 




// import './startUp'
// globalThis.WS_MANAGER = WS_MANAGER
let CURRENT_WINDOW_ID = null;
const browserEventListener = async (skip = false)=>{
    const win = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().windows.getLastFocused({
        populate: true
    });
    CURRENT_WINDOW_ID = win.id;
// let newColor = generateRandomColor(true);
// // let numOftabs = win.tabs.length;
// // let displayText = `${ numOftabs }|${ win.id }`
// // chrome.browserAction.setBadgeText({ text: `${displayText}` })
// // chrome.browserAction.setBadgeBackgroundColor({ color: newColor });
};
chrome.tabs.onActivated.addListener(async (tab)=>{
    await browserEventListener();
});
let windowFocusHandler;
chrome.windows.onFocusChanged.addListener(windowFocusHandler = async (win)=>{
    await browserEventListener();
});
chrome.runtime.onStartup.addListener(async ()=>{
    DEBUG && console.log('ON RUNTIME START UP');
    DEBUG && console.log('%c' + `Badge Color: ${newColor}`, `color:${newColor}`);
    await browserEventListener();
});
// ChromeRPC.onMessage(async (request, sender, sendResponse) => {
//   //  all the commands that needs to be refreshed when new options are sets
//   if (request.current_window_id) { // set current working window
//       CURRENT_WINDOW_ID = request.current_window_id
//   }
//   console.log(`CURRENT_WINDOW_ID = ${CURRENT_WINDOW_ID}`)
// });
const genCtxMenuEntry = ({ _ws = {}, ctx = null, parentId = null, act = true, withSubmenu = false, id = (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.randomId)(), title = null, type = 'normal' })=>{
    const _id = (0,_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.formatId)(_ws?.name || id);
    const _name = (0,_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.formatName)(_ws?.name || title);
    return {
        id: _id,
        title: _name,
        ...act && {
            act: (info, tab)=>{
                console.log(`Menu component ${_id}`);
            }
        },
        ...withSubmenu && {
            menu: generateUniqueSubMenu(WORKSPACEMENU, _id)
        },
        ...ctx && {
            contexts: ctx
        },
        parentId: parentId,
        type: type,
        ...type == 'checkbox' && {
            checked: true
        },
        // ...(parentId && {parentId: parentId}),
        ..._ws && {
            _ws: _ws
        }
    };
};
const create_empty_workspace_handler = async ()=>{
    let aNewWorkSpace = {};
    // call offscreen
    // service worker can't access prompt - so we use offscreenPrompt instead
    const wsName = await (0,_offScreenUtils__WEBPACK_IMPORTED_MODULE_4__.offScreenPrompt)('Please Enter a Name for your new WorkSpace');
    //   const wsName = prompt("Please Enter a Name for your new WorkSpace")
    let menuComponent = genCtxMenuEntry({
        _ws: _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.ws.fromWindows([
            {
                tabs: []
            }
        ], wsName, _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"]),
        ctx: null,
        parentId: null,
        withSubmenu: true
    });
    dynamicRootMenuWorkSpace.push(menuComponent);
    CTX_MENU.updateMenu();
    console.log({
        aNewWorkSpace,
        dynamicRootMenuWorkSpace
    });
    return aNewWorkSpace;
};
const create_workspace_handler = async (info, tab, current = true)=>{
    // service worker can't access prompt - so we use offscreenPrompt instead
    const wsName = await (0,_offScreenUtils__WEBPACK_IMPORTED_MODULE_4__.offScreenPrompt)('Please Enter a Name for your new WorkSpace');
    let aNewWorkSpace = {};
    if (current) {
        console.log("creating WS from current window", CURRENT_WINDOW_ID);
        const win = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().windows.get(CURRENT_WINDOW_ID, {
            populate: true
        });
        console.log(win);
        aNewWorkSpace = _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.ws.fromWindows([
            win
        ], wsName);
    } else {
        console.log("creating WS from ALL windows");
        const win = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_1___default().windows.getAll({
            populate: true
        });
        aNewWorkSpace = _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.ws.fromWindows(win, wsName);
    }
    _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].add(aNewWorkSpace);
    let menuComponent = genCtxMenuEntry({
        _ws: aNewWorkSpace,
        ctx: null,
        parentId: null,
        withSubmenu: true
    });
    dynamicRootMenuWorkSpace.push(menuComponent);
    CTX_MENU.updateMenu();
    return aNewWorkSpace;
};
const delete_workspace_handler = async (_id)=>{
    console.log(`${_id} Clicked`);
    //   const yesOrNo = prompt(`Are you Sure you want to DELETE "${_id}"? \nYes/No`).trim().toLowerCase()
    const yes = await (0,_offScreenUtils__WEBPACK_IMPORTED_MODULE_4__.offScreenConfirm)(`Are you Sure you want to DELETE "${_id}"?`);
    if (yes) {
        await _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].remove(_id);
        await CTX_MENU.deleteMenu(_id);
        dynamicRootMenuWorkSpace = dynamicRootMenuWorkSpace.filter((m)=>m.id != _id);
        CTX_MENU.updateMenu();
        console.log('Deleting WS - ', _id);
    } else {
        console.log(_id, 'Not Deleted - confirmation cancelled');
    }
};
const CONTEXTS = [
    "page",
    "frame",
    "selection",
    "link",
    "editable",
    "image",
    "video",
    "audio"
];
const WORKSPACEMENU = [
    {
        id: 'add_fn',
        title: 'Add this tab',
        act: (info, tab)=>{
            _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].all[info.parentMenuItemId].add(tab.url, tab.title);
            dynamicRootMenuWorkSpace = dynamicRootMenuWorkSpace.map((m)=>{
                return m.id != info.parentMenuItemId ? m : {
                    ...m,
                    ...{
                        menu: generateUniqueSubMenu(WORKSPACEMENU, info.parentMenuItemId)
                    }
                };
            });
            CTX_MENU.updateMenu();
        }
    },
    {
        id: 'remove_fn',
        title: 'Remove this tab',
        act: (info, tab)=>{
            console.log('context Menu-> remove_fn', info, tab, info.menuItemId);
            alert('Clicked ItemG');
        }
    },
    {
        id: 'peek_fn',
        title: 'Peek',
        act: (info, tab)=>{
            console.log('context Menu-> peek_fn', info, tab, info.menuItemId);
        },
        menu: []
    },
    {
        id: 'open_fn',
        title: 'Open',
        act: (info, tab)=>{
            _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].all[info.parentMenuItemId].open();
            console.log('context Menu-> open_fn', info, tab, info.menuItemId);
        }
    }
];
const generateWSDeleteList = ()=>{
    let res = Object.keys(_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].all).map((wsName)=>{
        return {
            id: (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.randomId)(),
            name: wsName,
            title: wsName,
            act: (info, tab)=>{
                delete_workspace_handler(wsName);
            }
        };
    }).sort((a, b)=>a.name > b.name ? 1 : b.name > a.name ? -1 : 0);
    return res;
};
// menu element need to have Unique IDs
const generateUniqueSubMenu = (m, parentName)=>{
    const arr1 = _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].get(parentName).windows.map((x)=>x.tabs.map((t)=>{
            return {
                title: t.title,
                url: t.url
            };
        }));
    const arr2 = Array.from({
        length: arr1.length - 1
    }, ()=>'|');
    const arr3 = (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.interleave)(arr1, arr2).flat().map((x)=>{
        if (x == '|') {
            return [
                {
                    id: (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.randomId)(),
                    type: "separator"
                },
                {
                    id: (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.randomId)(),
                    type: "separator"
                }
            ];
        }
        return {
            id: (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.randomId)(),
            name: x.title,
            title: x.title,
            act: (info, tab)=>{
                console.log('Opening URL - ', x.url);
            }
        };
    }).flat();
    // console.log(`generateUniqueSubMenu -> `, parentName, m)
    return m.map((item)=>{
        return {
            ...item,
            ...{
                id: `${item.id}_${(0,_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.formatId)(parentName)}`
            },
            ...item.id == 'peek_fn' && {
                menu: arr3
            }
        };
    });
};
const OPTIONMENU = [
    {
        id: "focus_option",
        type: "checkbox",
        checked: false,
        title: "Focus ( Temporarily close other tabs )",
        act: (info, tab)=>{
            console.log(info, tab);
        }
    },
    {
        id: "discard_option",
        type: "checkbox",
        checked: false,
        title: "Discard Tabs on Open",
        act: (info, tab)=>{
            console.log(info, tab);
        }
    }
];
const CREATEWSMENU = [
    {
        id: 'create_workspace_empty',
        title: 'Empty Workspace',
        act: create_empty_workspace_handler
    },
    {
        id: 'create_workspace_from_all',
        title: 'From All Windows',
        act: (info, tab)=>create_workspace_handler(info, tab, false)
    },
    {
        id: 'create_workspace_from_current',
        title: 'From Current Window',
        act: create_workspace_handler
    }
];
let DELETEMENU = [
    ...generateWSDeleteList()
];
const ROOTMENU = [
    {
        id: 'create_workspace',
        title: 'Create WorkSpace',
        menu: CREATEWSMENU
    },
    {
        id: 'delete_workspace',
        title: 'Delete WorkSpace',
        menu: DELETEMENU
    },
    // { id: 'delete_workspace', title: 'Delete WorkSpace', act: delete_workspace_handler },
    {
        id: 'option',
        title: 'Options',
        menu: OPTIONMENU
    },
    {
        id: (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.randomId)(),
        type: 'separator'
    }
];
const reloadSavedWS = ()=>{
    let res = [];
    console.log(structuredClone(_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"]));
    console.log(`reloadSavedWS`, _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].all);
    for (const [wsId, wsObj] of Object.entries(_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"].all)){
        res.push(genCtxMenuEntry({
            _ws: wsObj,
            ctx: null,
            parentId: null,
            withSubmenu: true
        }));
    }
    if (res.length == 0) {
        res.push(genCtxMenuEntry({
            _ws: _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.ws.fromWindows([
                {
                    tabs: []
                }
            ], 'news', _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"]),
            ctx: null,
            parentId: null,
            withSubmenu: true
        }), genCtxMenuEntry({
            _ws: _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.ws.fromWindows([
                {
                    tabs: []
                }
            ], 'school', _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"]),
            ctx: null,
            parentId: null,
            withSubmenu: true
        }), genCtxMenuEntry({
            _ws: _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.ws.fromWindows([
                {
                    tabs: []
                }
            ], 'games', _neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__["default"]),
            ctx: null,
            parentId: null,
            withSubmenu: true
        }));
    }
    return res.sort((a, b)=>a.id > b.id ? 1 : b.id > a.id ? -1 : 0);
};
let dynamicRootMenuWorkSpace = [
    ...reloadSavedWS()
].sort((a, b)=>a.id > b.id ? 1 : b.id > a.id ? -1 : 0);
globalThis.dynamicRootMenuWorkSpace = dynamicRootMenuWorkSpace;
class ctxMenu {
    static{
        this.listeners = {};
    }
    static{
        this.contexts = CONTEXTS;
    }
    static{
        this.workSpaces = [];
    }
    static{
        this.rootMenu = [];
    }
    constructor(entries = [], _rootMenu = []){
        this._reset();
        ctxMenu.rootMenu = _rootMenu.length ? _rootMenu : ROOTMENU;
        this.workSpaces = [];
        // append existing ws to the rootMenu
        for (const w of entries){
            this.workSpaces.push(w);
        }
        // create the chrome contextMenu from the rootMenu Array
        this.createMenu([
            ...ctxMenu.rootMenu,
            ...this.workSpaces
        ]);
        this.setOnClickHandler();
    }
    _reset() {
        chrome.contextMenus.removeAll((data)=>{
            console.log(`Ctx Menu -> Reset`);
        });
    }
    setOnClickHandler() {
        try {
            chrome.contextMenus.onClicked.addListener(async (info, tab)=>{
                await ctxMenu.listeners[info.menuItemId](info, tab);
            });
        } catch (error) {
            console.warn(error);
        }
    }
    removeOnClickHandler() {
        chrome.contextMenus.onClicked = null;
    }
    createMenu(menu, root = null) {
        // console.log("createMenu ->", menu, root)
        for (let _m of menu){
            let { id, title, menu, act, type, _ws } = _m;
            if (id in ctxMenu.listeners) {
                // console.log(`create -> [Del] - exiting id: ${id}`)
                this.deleteMenu(id);
            }
            let __title = title && `${_ws ? `⦿ ` : ''}${(0,_neoWorkSpace__WEBPACK_IMPORTED_MODULE_0__.formatName)(title?.replace('⦿', ''))} ${_ws ? `(${_ws.tabCount})` : ''}`.trim();
            chrome.contextMenus.create(// ⦾
            type == "separator" ? {
                id: id,
                type: "separator",
                parentId: root
            } : genCtxMenuEntry({
                id: id,
                // ...(title && {title: `${ _ws ? `⦿ ` : '' }${formatName(title.replace('⦿', '').trim())} ${ _ws ? `(${ _ws.tabCount })` : '' }`.trim()}),
                ...title && {
                    title: `${__title}`
                },
                ctx: ctxMenu.contexts,
                parentId: root,
                act: false,
                _ws: false,
                type: type || 'normal'
            }));
            if (act) {
                ctxMenu.listeners[id] = act;
            }
            if (menu) {
                this.createMenu(menu, id);
            }
        }
    }
    updateMenu(menu = [], root = null) {
        this._reset() // remove all so there is no ID issues
        ;
        const _menu = [
            ...ROOTMENU,
            ...dynamicRootMenuWorkSpace.sort((a, b)=>a.id > b.id ? 1 : b.id > a.id ? -1 : 0)
        ] // add all available menu
        ;
        _menu.find((x)=>x.id == "delete_workspace").menu = [
            ...generateWSDeleteList()
        ];
        this.createMenu(_menu);
    }
    deleteMenu(id) {
        if (id in ctxMenu.listeners) {
            // console.log(`Deleting ${id} - listener`)
            delete ctxMenu.listeners[id];
            chrome.contextMenus.remove(id, ()=>{
                if (chrome.runtime.lastError) {
                // console.log("error : ", chrome.runtime.lastError.message);
                }
            // console.log(`DELETED - context menu ws - ${ id }`)
            });
        }
    }
}
const listOfWorkSpaces = dynamicRootMenuWorkSpace;
console.log(listOfWorkSpaces.map((i)=>i.title));
const CTX_MENU = new ctxMenu(listOfWorkSpaces, ROOTMENU);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ "./app/scripts/libs/helpers.js":
/*!*************************************!*\
  !*** ./app/scripts/libs/helpers.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   closeEmptyTabs: () => (/* binding */ closeEmptyTabs),
/* harmony export */   closeTabs: () => (/* binding */ closeTabs),
/* harmony export */   currentDate: () => (/* binding */ currentDate),
/* harmony export */   interleave: () => (/* binding */ interleave),
/* harmony export */   openTab: () => (/* binding */ openTab),
/* harmony export */   randomId: () => (/* binding */ randomId)
/* harmony export */ });
// import { saveAs } from 'file-saver'
/**
 * close any empty tabs
 *
 * @param {Array} tabs - array of tabs
 * @returns id of closed empty tabs
 */ const closeTabs = async (tabsID)=>{
    if (tabsID.length > 0) {
        browser.tabs.remove(tabsID, (t)=>{
            DEBUG && console.log(`${tabsID.length || 0} closed`);
        });
    }
};
const closeEmptyTabs = (tabs)=>{
    const emptyTabs = tabs.filter((t)=>t.url.includes('chrome://newtab/')).map((t)=>t.id);
    if (emptyTabs.length > 0) {
        chrome.tabs.remove(emptyTabs, (t)=>{
            DEBUG && console.log(`${emptyTabs.length || 0} empty tabs closed`);
        });
    }
    return emptyTabs;
};
const findAndCloseDuplicateTabs = (_tabs = null)=>{
    let tabs = _tabs.map((t)=>{
        return {
            ...t,
            ...{
                url: t.url || t.pendingUrl
            }
        };
    });
    if (!tabs) {
        return;
    }
    // get unique tabs - the one we will keep
    const uniqueTabs = deduplicateArrayOfObject(tabs, 'url');
    // console.log("uniqueTabs=>", uniqueTabs)
    const uniqueTabsArr = [
        ...uniqueTabs.values()
    ];
    // console.log("uniqueTabs=>", uniqueTabsArr)
    // get the unique IDs
    const uniqueTabsID = uniqueTabsArr.map((t)=>t.id);
    //get the id of the tabs
    const allTabIDs = tabs.map((t)=>t.id);
    const duplicates = allTabIDs.filter((id)=>!uniqueTabsID.includes(id));
    closeTabs(duplicates);
    return uniqueTabsArr;
};
const discardThisTab = (tabId)=>{
    new Promise((resolve)=>{
        chrome.tabs.onUpdated.addListener(async function listener(tabId, info) {
            if (info.status === 'complete' && tabId === tab.id) {
                await chrome.tabs.discard(tab.id, (discaredTab)=>{
                    console.log(`created & Unloaded from mem -> ${tab.url}`);
                });
                chrome.tabs.onUpdated.removeListener(listener);
                resolve(tab);
            }
        });
    });
};
const openTab = async ({ urls = [], wID = null, meta = {} })=>{
    // const t = await browser.tabs.create({ url:_url, windowId: windowId })
    let t;
    if (wID) {
        t = new Promise((resolve)=>{
            chrome.tabs.create({
                url: urls,
                windowId: wID,
                ...meta
            }, async (tab1)=>{
                resolve(tab1);
            });
        });
    } else {
        t = new Promise((resolve)=>{
            chrome.windows.create({
                url: urls,
                ...meta
            }, async (w)=>{
                console.log(w);
                resolve(w);
            });
        });
    }
    return t;
};
// thanks to https://levelup.gitconnected.com/generate-unique-id-in-the-browser-without-a-library-50618cdc3cb1 :)
function randomId() {
    const uint32 = globalThis.crypto.getRandomValues(new Uint32Array(1))[0];
    return uint32.toString(16);
}
const saveToFile = (filename, dataString)=>{
    const blob = new Blob([
        dataString
    ], {
        type: 'text/plain;charset=utf-8'
    });
    // saveAs is from FileSaver.js
    saveAs(blob, filename);
};
const currentDate = ()=>{
    let date = new Date();
    date = date.toLocaleDateString(undefined, {
        day: '2-digit'
    }) + '-' + date.toLocaleDateString(undefined, {
        month: 'short'
    }) + '-' + date.toLocaleDateString(undefined, {
        year: 'numeric'
    });
    return date;
};
const interleave = ([x, ...xs], ys = [])=>x === undefined ? ys // base: no x
     : [
        x,
        ...interleave(ys, xs)
    ] // inductive: some x
;


/***/ }),

/***/ "./app/scripts/libs/neoWorkSpace.js":
/*!******************************************!*\
  !*** ./app/scripts/libs/neoWorkSpace.js ***!
  \******************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _stringifyAndCompress: () => (/* binding */ _stringifyAndCompress),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   formatId: () => (/* binding */ formatId),
/* harmony export */   formatName: () => (/* binding */ formatName),
/* harmony export */   ws: () => (/* binding */ ws),
/* harmony export */   wsManager: () => (/* binding */ wsManager)
/* harmony export */ });
/* harmony import */ var lz_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lz-string */ "./node_modules/.pnpm/lz-string@1.5.0/node_modules/lz-string/libs/lz-string.js");
/* harmony import */ var lz_string__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lz_string__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage */ "./app/scripts/libs/storage.js");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./helpers */ "./app/scripts/libs/helpers.js");



/**
 * windowsArr = await ts2.browser.windows.getAll({populate:true})
 * _ws = ws.fromWindows(windowsArr)
 *
 * ws(name, windows=[{meta: {}, urls=[]}, {meta: {}, urls=[]}])
 * ws.fromUrls(name, urls)
 * ws.fromWindows(name)
 * */ globalThis.lzStringCompress = lz_string__WEBPACK_IMPORTED_MODULE_0__.compressToUTF16;
globalThis.lzStringDecompress = lz_string__WEBPACK_IMPORTED_MODULE_0__.decompressFromUTF16;
const _stringifyAndCompress = (Obj, verbose = false)=>{
    const strData = JSON.stringify(Obj);
    const compressed = (0,lz_string__WEBPACK_IMPORTED_MODULE_0__.compressToUTF16)(strData);
    if (verbose) {
        console.log(strData);
        console.log(compressed);
    }
    console.log("Initial Size: " + strData.length);
    console.log("Compresseed Size: " + compressed.length);
    return compressed;
};
class ws {
    static{
        this.totalWSCount = 0;
    }
    constructor(name1, _windows = [], skip = false, wsManager = null){
        this.name = formatName(name1);
        this.wsManager = wsManager;
        if (!skip) {
            _windows.forEach((w)=>{
                const { meta, urls, tabs } = w;
                if (tabs != []) {
                    return ws.fromTabObj(this.name, tabs);
                }
                return ws.fromURLs(this.name, urls, meta, true);
            });
        }
        this.windows = _windows;
        ws.totalWSCount += 1;
        this.winCount = this.windows.length;
        this.tabCount = this.windows.reduce((acc, w)=>{
            return acc + w.tabs.length;
        }, 0);
        if (wsManager) {
            this.wsManager.add(this);
        }
    }
    refreshCounts() {
        this.winCount = this.windows.length;
        this.tabCount = this.windows.reduce((acc, w)=>{
            return acc + w.tabs.length;
        }, 0);
    }
    static fromTabObj(name1, tabs, meta = {}) {
        return {
            id: `meta_${ws.totalWSCount}`,
            bounds: [],
            meta: meta,
            tabs: tabs
        };
    }
    static fromURLs(name1, urls, meta = {}, returnRawWindow = false) {
        const aWindow = {
            id: `meta_${ws.totalWSCount}`,
            bounds: [],
            meta: meta,
            tabs: [
                urls.map((url)=>{
                    return {
                        id: null,
                        url: url,
                        title: null,
                        pinned: null,
                        lastActive: null
                    };
                })
            ]
        };
        if (returnRawWindow) {
            return asWindow;
        }
        const _ws_structure = {
            name: name1,
            windows: [
                aWindow
            ]
        };
        ws.totalWSCount += 1;
        return _ws_structure;
    }
    static fromWindows(windowsArr, name1, manager) {
        const windows1 = windowsArr.map((w)=>{
            const { height, width, top, left, id, tabs } = w;
            return {
                id,
                bounds: {
                    height,
                    width,
                    top,
                    left
                },
                tabs: tabs.map((t)=>{
                    const { url, title, id, pinned } = t;
                    return {
                        url,
                        title,
                        id,
                        pinned
                    };
                })
            };
        });
        return new ws(name1, windows1, true, manager);
    }
    isUrlInWS(url) {
        // return 1 or >1 if true
        return this.windows?.map((w)=>{
            return w.tabs.filter((t)=>t.url.includes(url));
        }).flat()?.length != 0;
    }
    find(url) {
        // - find all occurence of an url in a WS - return an array of [{ windowIdx, tabindex, urlValue }]
        return this.windows.map((w, idx1)=>{
            return w.tabs.map((t, idx2)=>t.url.includes(url) ? {
                    w: idx1,
                    t: idx2,
                    url: t.url
                } : null).filter((i)=>i);
        }).filter((i)=>i.length).flat();
    }
    toString() {
        return JSON.stringify({
            name,
            windows
        });
    }
    save(toLocalStorage = false, compress = false) {
        let wsStr = JSON.stringify({
            name: this.name,
            windows: this.windows
        });
        if (compress) {
            wsStr = _stringifyAndCompress(wsStr, true);
        }
        if (toLocalStorage) {
            _storage__WEBPACK_IMPORTED_MODULE_1__.localStorage.setItem(this.name, wsStr);
        }
        return wsStr;
    }
    static reload(savedStr) {
        const { name: name1, windows: windows1 } = JSON.parse(savedStr);
        return new ws(name1, windows1, true);
    }
    add(url, title = undefined) {
        this.windows?.[this.winCount - 1]?.tabs.push({
            id: null,
            url: url,
            title: title || url,
            pinned: null,
            lastActive: null
        });
        this.refreshCounts();
        console.log(`Added URL : ${url} to ${this.name}`);
        this.save();
    }
    update(urls) {
        _update = urls.map((url)=>{
            return {
                id: null,
                url: url,
                title: null,
                pinned: null,
                lastActive: null
            };
        });
        this.windows.push(_update);
        this.refreshCounts();
        this.save();
    }
    remove(url) {}
    open() {
        this.windows.map((w)=>{
            (0,_helpers__WEBPACK_IMPORTED_MODULE_2__.openTab)({
                urls: w.tabs.map((t)=>t.url)
            });
        });
    }
}
const formatName = (name1)=>{
    let _name = name1.trim().toLowerCase();
    return _name[0].toUpperCase() + _name.slice(1);
};
const formatId = (name1)=>{
    let id = name1.trim().replace(/\s/g, '_').toLowerCase();
    return id;
};
// just a list of available ws
class wsManager {
    constructor(){
        this.all = {};
        this.name = "WSP_MANAGER";
        // this.load()
        this.noSave = false;
    // this.initialized = false
    }
    add(_ws) {
        const _id1 = formatId(_ws.name);
        if (_id1 in this.all) {
            console.log(`The Workspace name:'${_ws.name}', id:'${_id1} '- already in used`);
        } else {
            this.all[_id1] = _ws;
        }
        if (!this.noSave) {
            this.save();
        }
    }
    update(_id1, tabs) {}
    remove(nameOrId) {
        const _id1 = formatId(nameOrId);
        delete this.all[_id1];
        this.save();
    }
    open(id) {
        this.all[_id].open();
    }
    reHydrate({ name: name1 = "", windows: windows1 = [], winCount = 0, tabCount = 0 }) {
        console.log("reHydrating... ", name1, windows1, winCount, tabCount, this);
        return new ws(name1, windows1, false, this);
    }
    get(nameOrId) {
        const _id1 = formatId(nameOrId);
        return this.all[_id1];
    }
    save() {
        // const _all_ws_str = JSON.stringify(this.all)
        // localStorage.setItem(this.name, _all_ws_str);
        // console.log("Saved wsManager =>", _all_ws_str)
        // return _all_ws_str
        let toBeSaved = {};
        for (const [wsId, wsObj] of Object.entries(this.all)){
            wsObj.save(true, true);
            console.log("sub save done");
            toBeSaved[wsId] = {
                ...wsObj,
                ...{
                    wsManager: null
                }
            } // remove the wsManager to not have a circular dependency while stringifying all this
            ;
        }
        const _all_ws_str = JSON.stringify(toBeSaved);
        _storage__WEBPACK_IMPORTED_MODULE_1__.localStorage.setItem(this.name, _all_ws_str);
        console.log("Saved wsManager =>", _all_ws_str);
        return _all_ws_str;
    }
    async load() {
        console.log("Loading wsManager");
        // (async ()=>{
        this.noSave = true;
        const _all_ws_str = await _storage__WEBPACK_IMPORTED_MODULE_1__.localStorage.getItem(this.name);
        console.log("ASYNC Loading wsManager", _all_ws_str);
        if (_all_ws_str) {
            const saved = JSON.parse(_all_ws_str);
            // console.log(saved)
            for (const [wsId, wsObj] of Object.entries(saved)){
                console.log(wsId, wsObj);
                this.reHydrate(wsObj);
            }
            console.log("reLoading wsManager =>", this.all);
        }
        this.noSave = false;
    // this.initialized = true
    // })()
    }
    export() {
        const dataString = this.save();
        saveToFile(`workSpace_backup_${(0,_helpers__WEBPACK_IMPORTED_MODULE_2__.currentDate)()}.txt`, dataString);
    }
}
// TODO: refactor this - low priority (mv3)
const WS_MANAGER = new wsManager();
await WS_MANAGER.load() // no async constructors? => top level await FTW!
;
console.log({
    WS_MANAGER
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WS_MANAGER);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } }, 1);

/***/ }),

/***/ "./app/scripts/libs/offScreenUtils.js":
/*!********************************************!*\
  !*** ./app/scripts/libs/offScreenUtils.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   offScreenConfirm: () => (/* binding */ offScreenConfirm),
/* harmony export */   offScreenPrompt: () => (/* binding */ offScreenPrompt)
/* harmony export */ });
// --------------------------------------------------------------------------------------------------------- //
// --------------------------------------------------------------------------------------------------------- //
// --------------------------------------------------------------------------------------------------------- //
// Offscreen Setup - ignore
// --------------------------------------------------------------------------------------------------------- //
const OFFSCREEN_DOCUMENT_PATH = '/offscreen.html';
// A global promise to avoid concurrency issues
let creating;
// There can only be one offscreenDocument. So we create a helper function
// that returns a boolean indicating if a document is already active.
async function hasDocument() {
    // Check all windows controlled by the service worker to see if one
    // of them is the offscreen document with the given path
    const matchedClients = await clients.matchAll();
    return matchedClients.some((c)=>c.url === chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH));
}
async function setupOffscreenDocument(path) {
    //if we do not have a document, we are already setup and can skip
    if (!await hasDocument()) {
        // create offscreen document
        if (creating) {
            await creating;
        } else {
            creating = chrome.offscreen.createDocument({
                url: path,
                reasons: [
                    chrome.offscreen.Reason.GEOLOCATION || chrome.offscreen.Reason.DOM_SCRAPING
                ],
                justification: 'add justification for geolocation use here'
            });
            await creating;
            creating = null;
        }
    }
}
async function closeOffscreenDocument() {
    if (!await hasDocument()) {
        return;
    }
    await chrome.offscreen.closeDocument();
}
// --------------------------------------------------------------------------------------------------------- //
// --------------------------------------------------------------------------------------------------------- //
// --------------------------------------------------------------------------------------------------------- //
// Offscreen functions
// --------------------------------------------------------------------------------------------------------- //
/**
 * calls window.prompt
 *
 * @export
 * @param {*} promptMessage
 * @return {*}
 */ async function offScreenPrompt(promptMessage) {
    await setupOffscreenDocument(OFFSCREEN_DOCUMENT_PATH);
    const wsName = await chrome.runtime.sendMessage({
        type: 'prompt',
        target: 'offscreen',
        promptMessage: promptMessage
    });
    console.log({
        wsName
    });
    await closeOffscreenDocument();
    return wsName;
}
/**
 * calls window.confirm
 *
 * @export
 * @param {str} confirmMessage
 * @return {boolean} true / false
 */ async function offScreenConfirm(confirmMessage) {
    await setupOffscreenDocument(OFFSCREEN_DOCUMENT_PATH);
    const confirm = await chrome.runtime.sendMessage({
        type: 'confirm',
        target: 'offscreen',
        confirmMessage: confirmMessage
    });
    console.log({
        confirm
    });
    await closeOffscreenDocument();
    return confirm;
}


/***/ }),

/***/ "./app/scripts/libs/storage.js":
/*!*************************************!*\
  !*** ./app/scripts/libs/storage.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   localStorage: () => (/* binding */ localStorage)
/* harmony export */ });
// https://stackoverflow.com/a/70708120/623546
const localStorage = {
    getAllItems: ()=>chrome.storage.local.get(),
    getItem: async (key)=>(await chrome.storage.local.get(key))[key],
    setItem: (key, val)=>chrome.storage.local.set({
            [key]: val
        }),
    removeItems: (keys)=>chrome.storage.local.remove(keys)
};
globalThis.localStorage = localStorage;
console.warn('localStorage', localStorage);


/***/ }),

/***/ "./app/scripts/libs/utils.js":
/*!***********************************!*\
  !*** ./app/scripts/libs/utils.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChromeRPC: () => (/* binding */ ChromeRPC),
/* harmony export */   appendAndReorganize: () => (/* binding */ appendAndReorganize),
/* harmony export */   asyncPromisify: () => (/* binding */ asyncPromisify),
/* harmony export */   deepMerge: () => (/* binding */ deepMerge),
/* harmony export */   flatten: () => (/* binding */ flatten),
/* harmony export */   generateRandomColor: () => (/* binding */ generateRandomColor),
/* harmony export */   get: () => (/* binding */ get),
/* harmony export */   improvedConsoleLog: () => (/* binding */ improvedConsoleLog),
/* harmony export */   isInExcludedList: () => (/* binding */ isInExcludedList),
/* harmony export */   loadFromStorage: () => (/* binding */ loadFromStorage),
/* harmony export */   pivotThis: () => (/* binding */ pivotThis),
/* harmony export */   promisify: () => (/* binding */ promisify),
/* harmony export */   saveToStorage: () => (/* binding */ saveToStorage),
/* harmony export */   set: () => (/* binding */ set),
/* harmony export */   shiftLeftAndAppend: () => (/* binding */ shiftLeftAndAppend),
/* harmony export */   sleep: () => (/* binding */ sleep),
/* harmony export */   timeout: () => (/* binding */ timeout)
/* harmony export */ });
/**
 * Chrome Storage setter helper
 *
 * @param {name: value} obj
 * @returns Promise
 */ const set = (obj)=>new Promise((resolve, reject)=>{
        const key = Object.keys(obj)[0];
        const o = obj;
        o[key] = JSON.stringify(obj[key]);
        chrome.storage.local.set(o, ()=>{
            console.log(`${JSON.stringify(o)} saved`);
            resolve(o);
        });
    });
/**
 * Chrome Storage getter helper
 *
 * @param {string} name
 * @returns Promise
 */ const get = (name)=>new Promise((resolve, reject)=>{
        chrome.storage.local.get(name, (dataObj)=>{
            const res = Object.keys(dataObj).includes(name) ? dataObj[name] : '{}';
            resolve(JSON.parse(res));
        });
    });
const ChromeRPC = {
    _getExtId: ()=>chrome.runtime.id,
    sendMessage: (params, fn)=>{
        // console.log(chrome.runtime.id)
        chrome.runtime.sendMessage(chrome.runtime.id, params, fn);
    },
    onMessage: (MessageHandler)=>{
        chrome.runtime.onMessage.addListener(MessageHandler);
    }
};
// inspired from https://gist.github.com/pincheira/2724082#gistcomment-2662810
const improvedConsoleLog = (name, console1, debugFlag)=>{
    const DEBUG = debugFlag;
    const orig = console1.log;
    function log(...args) {
        if (DEBUG) {
            orig.apply(console1, [
                `[${name}]:`,
                args
            ]);
        }
    }
    return log;
};
const promisify = (fn)=>(...args)=>new Promise((resolve, reject)=>{
            fn(...args, (value, error)=>{
                if (error) {
                    reject(error);
                } else {
                    resolve(value);
                }
            });
        });
const asyncPromisify = (fn)=>async (...args)=>new Promise((resolve, reject)=>fn(...args, (val, err)=>err ? reject(err) : resolve(val)));
/**
 * Shift Left by 1 and append new value
 * @param  {[type]} arr   an array
 * @param  {[type]} value
 * @return {array}  retuns the modified array
 */ const shiftLeftAndAppend = (arr, value)=>{
    arr.push.apply(arr.push(value), arr.splice(0, 1));
    return arr;
};
/**
 * keep the last selected window id at the most right of the array
 * this is used to select the last 2 window to be merged
 *
 */ const appendAndReorganize = (arr, x)=>[
        ...arr.filter((t)=>t !== x),
        x
    ];
/**
 * Array flattener helper function
 *
 * @param {any} arr
 */ const flatten = (arr)=>arr.reduce((a, b)=>a.concat(Array.isArray(b) ? flatten(b) : b), []);
/**
 * reorder arr1 according to order of elments in arr2
 * @param  {[type]} arr1 [description]
 * @param  {[type]} arr2 [description]
 * @param  {[type]} unordered_last defines what to do with items in arr2 but not in arr1
 * @return {[type]}      [description]
 */ // arr1 = [3,2,4,5,22,1,0,2]
// arr2 = [1,3,4,2,5,6]
const alignArrays = (arr1, arr2, unordered_last = true)=>{
    let _arr1 = [
        ...arr1
    ];
    _arr1.sort((a, b)=>arr2.indexOf(a) - arr2.indexOf(b));
    if (unordered_last) {
        const ordered = _arr1.filter((x)=>arr2.includes(x));
        const unordered = _arr1.filter((x)=>!arr2.includes(x));
        // console.log(ordered, unordered)
        _arr1 = [
            ...ordered,
            ...unordered
        ];
    // console.log(_arr1)
    }
    return _arr1;
};
const intersection = (arr1, arr2)=>arr1.filter((x)=>arr2.includes(x));
const difference = (arr1, arr2)=>arr1.filter((x)=>!arr2.includes(x));
const symmetric_difference = (arr1, arr2)=>arr1.filter((x)=>!arr2.includes(x)).concat(arr2.filter((x)=>!arr1.includes(x)));
/**
 *  find the correct window id for each tab_ids
 * @param  {Object} state
 * @param  {Object} cc    map of {
 *                           tab_id: urls,
 *                           ...
 *                        }
 * @return {Object}       map of {
 *                            w_id: [ tab_id, ...],
 *                            ...
 *                         }
 */ // const _reversed_map = (state, cc ) =>
//     state.map(w => {
//       return {[w.id]: [...Object.keys(cc).filter(_id => w.tabs.map(t => t.id).includes(+_id)) ]}
//     }).reduce((acc, val) => {return {...val, ...acc}})
/**
 * pivot a set of data according to the index
 * aka, emulate a groupBy column...
 *
 * @param  {[type]} _dict      the dictionary to be pivoted
 * @param  {[type]} idx        index of the column to be used a new dictionary key
 * @param  {[type]} inThisCol      optional column for further filtering of inner array
 * @param  {[type]} ignoreValue    value to be ignored related to inThisCol
 * @return {[type]}            [description]
 */ const pivotThis = (_dict, idx, inThisCol, ignoreValue)=>Object.values(_dict).filter((el)=>!(el[0] instanceof Array)) // dont care about nested array
    .filter((el)=>inThisCol ? el[inThisCol] !== ignoreValue : el).map((x)=>({
            [x[idx]]: x
        })).reduce((acc, val)=>{
        const newKey = Object.keys(val)[0];
        const res = {
            [newKey]: Object.keys(acc).includes(newKey) ? [
                ...acc[newKey],
                [
                    ...val[newKey]
                ]
            ] : [
                val[newKey]
            ]
        };
        return {
            ...acc,
            ...res
        };
    }, {});
const sleep = (ms)=>{
    return new Promise((resolve)=>setTimeout(resolve, ms));
};
const timeout = sleep;
// export const sleepFor = (time=1000, thenDo=()=>{}) => setTimeout(function(){
//     // thenDo()
//     console.log("DONESLEEPING!!!!!")
// }, time);
// https://stackoverflow.com/questions/5560248/programmatically-lighten-or-darken-a-hex-color-or-rgb-and-blend-colors
// thanks to https://github.com/PimpTrizkit/PJs/wiki/12.-Shade,-Blend-and-Convert-a-Web-Color-(pSBC.js)
// function shadeHexColor(color, percent) {
//   const f = parseInt(color.slice(1), 16); const t = percent < 0 ? 0 : 255; const p = percent < 0 ? percent * -1 : percent; const R = f >> 16; const G = f >> 8 & 0x00FF; const B = f & 0x0000FF;
//   return `#${(0x1000000 + (Math.round((t - R) * p) + R) * 0x10000 + (Math.round((t - G) * p) + G) * 0x100 + (Math.round((t - B) * p) + B)).toString(16).slice(1)}`;
// }
// https://stackoverflow.com/a/50228121/623546
function deepMerge(current, update) {
    Object.keys(update).forEach((key)=>{
        // if update[key] exist, and it's not a string or array,
        // we go in one level deeper
        if (current.hasOwnProperty(key) && typeof current[key] === 'object' && !(current[key] instanceof Array)) {
            deepMerge(current[key], update[key]);
        // if update[key] doesn't exist in current, or it's a string
        // or array, then assign/overwrite current[key] to update[key]
        } else {
            current[key] = update[key];
        }
    });
    return current;
}
const isInExcludedList = (domain_str, excluded_list)=>// console.log(domain_str, excluded_list,  excluded_list.some(
    //         (x)=> domain_str.toLowerCase().includes(x.toLowerCase())
    //       ))
    excluded_list.some((x)=>domain_str.toLowerCase().includes(x.toLowerCase()));
const generateRandomColor = (cycleColors)=>{
    /*
  *  dark mint green - #137a63 - dark blue - #137
  * #41296b
  */ const currentVersionColor = '#41296b';
    return cycleColors ? `#${((1 << 24) * Math.random() | 0).toString(16)}`.padEnd(7, 0) : currentVersionColor;
};
const saveToStorage = (itemObject, storageType = 'sync')=>{
    storageType = storageType.toLowerCase();
    storageType = [
        'sync',
        'local'
    ].includes(storageType) ? storageType : 'local';
    return chrome.storage[storageType].set(itemObject, ()=>{
        console.log('Item saved - ', itemObject);
    });
};
const loadFromStorage = async (itemStr)=>{
    return chrome.storage.sync.get([
        itemStr
    ], (store)=>{
        console.log(`\u2192\u21F4 ${itemStr}`, store);
    });
};


/***/ }),

/***/ "./node_modules/.pnpm/webextension-polyfill@0.10.0/node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/webextension-polyfill@0.10.0/node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.10.0 - Fri Aug 12 2022 19:42:44 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!globalThis.chrome?.runtime?.id) {
    throw new Error("This script should only be loaded in a browser extension.");
  }

  if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received."; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      });

      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */


        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {}
          /* wrappers */
          , {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    }; // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			if (cachedModule.error !== undefined) throw cachedModule.error;
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		try {
/******/ 			var execOptions = { id: moduleId, module: module, factory: __webpack_modules__[moduleId], require: __webpack_require__ };
/******/ 			__webpack_require__.i.forEach(function(handler) { handler(execOptions); });
/******/ 			module = execOptions.module;
/******/ 			execOptions.factory.call(module.exports, module, module.exports, execOptions.require);
/******/ 		} catch(e) {
/******/ 			module.error = e;
/******/ 			throw e;
/******/ 		}
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = __webpack_module_cache__;
/******/ 	
/******/ 	// expose the module execution interceptor
/******/ 	__webpack_require__.i = [];
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/async module */
/******/ 	(() => {
/******/ 		var webpackQueues = typeof Symbol === "function" ? Symbol("webpack queues") : "__webpack_queues__";
/******/ 		var webpackExports = typeof Symbol === "function" ? Symbol("webpack exports") : "__webpack_exports__";
/******/ 		var webpackError = typeof Symbol === "function" ? Symbol("webpack error") : "__webpack_error__";
/******/ 		var resolveQueue = (queue) => {
/******/ 			if(queue && queue.d < 1) {
/******/ 				queue.d = 1;
/******/ 				queue.forEach((fn) => (fn.r--));
/******/ 				queue.forEach((fn) => (fn.r-- ? fn.r++ : fn()));
/******/ 			}
/******/ 		}
/******/ 		var wrapDeps = (deps) => (deps.map((dep) => {
/******/ 			if(dep !== null && typeof dep === "object") {
/******/ 				if(dep[webpackQueues]) return dep;
/******/ 				if(dep.then) {
/******/ 					var queue = [];
/******/ 					queue.d = 0;
/******/ 					dep.then((r) => {
/******/ 						obj[webpackExports] = r;
/******/ 						resolveQueue(queue);
/******/ 					}, (e) => {
/******/ 						obj[webpackError] = e;
/******/ 						resolveQueue(queue);
/******/ 					});
/******/ 					var obj = {};
/******/ 					obj[webpackQueues] = (fn) => (fn(queue));
/******/ 					return obj;
/******/ 				}
/******/ 			}
/******/ 			var ret = {};
/******/ 			ret[webpackQueues] = x => {};
/******/ 			ret[webpackExports] = dep;
/******/ 			return ret;
/******/ 		}));
/******/ 		__webpack_require__.a = (module, body, hasAwait) => {
/******/ 			var queue;
/******/ 			hasAwait && ((queue = []).d = -1);
/******/ 			var depQueues = new Set();
/******/ 			var exports = module.exports;
/******/ 			var currentDeps;
/******/ 			var outerResolve;
/******/ 			var reject;
/******/ 			var promise = new Promise((resolve, rej) => {
/******/ 				reject = rej;
/******/ 				outerResolve = resolve;
/******/ 			});
/******/ 			promise[webpackExports] = exports;
/******/ 			promise[webpackQueues] = (fn) => (queue && fn(queue), depQueues.forEach(fn), promise["catch"](x => {}));
/******/ 			module.exports = promise;
/******/ 			body((deps) => {
/******/ 				currentDeps = wrapDeps(deps);
/******/ 				var fn;
/******/ 				var getResult = () => (currentDeps.map((d) => {
/******/ 					if(d[webpackError]) throw d[webpackError];
/******/ 					return d[webpackExports];
/******/ 				}))
/******/ 				var promise = new Promise((resolve) => {
/******/ 					fn = () => (resolve(getResult));
/******/ 					fn.r = 0;
/******/ 					var fnQueue = (q) => (q !== queue && !depQueues.has(q) && (depQueues.add(q), q && !q.d && (fn.r++, q.push(fn))));
/******/ 					currentDeps.map((dep) => (dep[webpackQueues](fnQueue)));
/******/ 				});
/******/ 				return fn.r ? promise : getResult();
/******/ 			}, (err) => ((err ? reject(promise[webpackError] = err) : outerResolve(exports)), resolveQueue(queue)));
/******/ 			queue && queue.d < 0 && (queue.d = 0);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript update chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference all chunks
/******/ 		__webpack_require__.hu = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + "." + __webpack_require__.h() + ".hot-update.js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get update manifest filename */
/******/ 	(() => {
/******/ 		__webpack_require__.hmrF = () => ("background_js." + __webpack_require__.h() + ".hot-update.json");
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/getFullHash */
/******/ 	(() => {
/******/ 		__webpack_require__.h = () => ("4be1769d8564fa3f5606")
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "oakley:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hot module replacement */
/******/ 	(() => {
/******/ 		var currentModuleData = {};
/******/ 		var installedModules = __webpack_require__.c;
/******/ 		
/******/ 		// module and require creation
/******/ 		var currentChildModule;
/******/ 		var currentParents = [];
/******/ 		
/******/ 		// status
/******/ 		var registeredStatusHandlers = [];
/******/ 		var currentStatus = "idle";
/******/ 		
/******/ 		// while downloading
/******/ 		var blockingPromises = 0;
/******/ 		var blockingPromisesWaiting = [];
/******/ 		
/******/ 		// The update info
/******/ 		var currentUpdateApplyHandlers;
/******/ 		var queuedInvalidatedModules;
/******/ 		
/******/ 		// eslint-disable-next-line no-unused-vars
/******/ 		__webpack_require__.hmrD = currentModuleData;
/******/ 		
/******/ 		__webpack_require__.i.push(function (options) {
/******/ 			var module = options.module;
/******/ 			var require = createRequire(options.require, options.id);
/******/ 			module.hot = createModuleHotObject(options.id, module);
/******/ 			module.parents = currentParents;
/******/ 			module.children = [];
/******/ 			currentParents = [];
/******/ 			options.require = require;
/******/ 		});
/******/ 		
/******/ 		__webpack_require__.hmrC = {};
/******/ 		__webpack_require__.hmrI = {};
/******/ 		
/******/ 		function createRequire(require, moduleId) {
/******/ 			var me = installedModules[moduleId];
/******/ 			if (!me) return require;
/******/ 			var fn = function (request) {
/******/ 				if (me.hot.active) {
/******/ 					if (installedModules[request]) {
/******/ 						var parents = installedModules[request].parents;
/******/ 						if (parents.indexOf(moduleId) === -1) {
/******/ 							parents.push(moduleId);
/******/ 						}
/******/ 					} else {
/******/ 						currentParents = [moduleId];
/******/ 						currentChildModule = request;
/******/ 					}
/******/ 					if (me.children.indexOf(request) === -1) {
/******/ 						me.children.push(request);
/******/ 					}
/******/ 				} else {
/******/ 					console.warn(
/******/ 						"[HMR] unexpected require(" +
/******/ 							request +
/******/ 							") from disposed module " +
/******/ 							moduleId
/******/ 					);
/******/ 					currentParents = [];
/******/ 				}
/******/ 				return require(request);
/******/ 			};
/******/ 			var createPropertyDescriptor = function (name) {
/******/ 				return {
/******/ 					configurable: true,
/******/ 					enumerable: true,
/******/ 					get: function () {
/******/ 						return require[name];
/******/ 					},
/******/ 					set: function (value) {
/******/ 						require[name] = value;
/******/ 					}
/******/ 				};
/******/ 			};
/******/ 			for (var name in require) {
/******/ 				if (Object.prototype.hasOwnProperty.call(require, name) && name !== "e") {
/******/ 					Object.defineProperty(fn, name, createPropertyDescriptor(name));
/******/ 				}
/******/ 			}
/******/ 			fn.e = function (chunkId) {
/******/ 				return trackBlockingPromise(require.e(chunkId));
/******/ 			};
/******/ 			return fn;
/******/ 		}
/******/ 		
/******/ 		function createModuleHotObject(moduleId, me) {
/******/ 			var _main = currentChildModule !== moduleId;
/******/ 			var hot = {
/******/ 				// private stuff
/******/ 				_acceptedDependencies: {},
/******/ 				_acceptedErrorHandlers: {},
/******/ 				_declinedDependencies: {},
/******/ 				_selfAccepted: false,
/******/ 				_selfDeclined: false,
/******/ 				_selfInvalidated: false,
/******/ 				_disposeHandlers: [],
/******/ 				_main: _main,
/******/ 				_requireSelf: function () {
/******/ 					currentParents = me.parents.slice();
/******/ 					currentChildModule = _main ? undefined : moduleId;
/******/ 					__webpack_require__(moduleId);
/******/ 				},
/******/ 		
/******/ 				// Module API
/******/ 				active: true,
/******/ 				accept: function (dep, callback, errorHandler) {
/******/ 					if (dep === undefined) hot._selfAccepted = true;
/******/ 					else if (typeof dep === "function") hot._selfAccepted = dep;
/******/ 					else if (typeof dep === "object" && dep !== null) {
/******/ 						for (var i = 0; i < dep.length; i++) {
/******/ 							hot._acceptedDependencies[dep[i]] = callback || function () {};
/******/ 							hot._acceptedErrorHandlers[dep[i]] = errorHandler;
/******/ 						}
/******/ 					} else {
/******/ 						hot._acceptedDependencies[dep] = callback || function () {};
/******/ 						hot._acceptedErrorHandlers[dep] = errorHandler;
/******/ 					}
/******/ 				},
/******/ 				decline: function (dep) {
/******/ 					if (dep === undefined) hot._selfDeclined = true;
/******/ 					else if (typeof dep === "object" && dep !== null)
/******/ 						for (var i = 0; i < dep.length; i++)
/******/ 							hot._declinedDependencies[dep[i]] = true;
/******/ 					else hot._declinedDependencies[dep] = true;
/******/ 				},
/******/ 				dispose: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				addDisposeHandler: function (callback) {
/******/ 					hot._disposeHandlers.push(callback);
/******/ 				},
/******/ 				removeDisposeHandler: function (callback) {
/******/ 					var idx = hot._disposeHandlers.indexOf(callback);
/******/ 					if (idx >= 0) hot._disposeHandlers.splice(idx, 1);
/******/ 				},
/******/ 				invalidate: function () {
/******/ 					this._selfInvalidated = true;
/******/ 					switch (currentStatus) {
/******/ 						case "idle":
/******/ 							currentUpdateApplyHandlers = [];
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							setStatus("ready");
/******/ 							break;
/******/ 						case "ready":
/******/ 							Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 								__webpack_require__.hmrI[key](
/******/ 									moduleId,
/******/ 									currentUpdateApplyHandlers
/******/ 								);
/******/ 							});
/******/ 							break;
/******/ 						case "prepare":
/******/ 						case "check":
/******/ 						case "dispose":
/******/ 						case "apply":
/******/ 							(queuedInvalidatedModules = queuedInvalidatedModules || []).push(
/******/ 								moduleId
/******/ 							);
/******/ 							break;
/******/ 						default:
/******/ 							// ignore requests in error states
/******/ 							break;
/******/ 					}
/******/ 				},
/******/ 		
/******/ 				// Management API
/******/ 				check: hotCheck,
/******/ 				apply: hotApply,
/******/ 				status: function (l) {
/******/ 					if (!l) return currentStatus;
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				addStatusHandler: function (l) {
/******/ 					registeredStatusHandlers.push(l);
/******/ 				},
/******/ 				removeStatusHandler: function (l) {
/******/ 					var idx = registeredStatusHandlers.indexOf(l);
/******/ 					if (idx >= 0) registeredStatusHandlers.splice(idx, 1);
/******/ 				},
/******/ 		
/******/ 				//inherit from previous dispose call
/******/ 				data: currentModuleData[moduleId]
/******/ 			};
/******/ 			currentChildModule = undefined;
/******/ 			return hot;
/******/ 		}
/******/ 		
/******/ 		function setStatus(newStatus) {
/******/ 			currentStatus = newStatus;
/******/ 			var results = [];
/******/ 		
/******/ 			for (var i = 0; i < registeredStatusHandlers.length; i++)
/******/ 				results[i] = registeredStatusHandlers[i].call(null, newStatus);
/******/ 		
/******/ 			return Promise.all(results);
/******/ 		}
/******/ 		
/******/ 		function unblock() {
/******/ 			if (--blockingPromises === 0) {
/******/ 				setStatus("ready").then(function () {
/******/ 					if (blockingPromises === 0) {
/******/ 						var list = blockingPromisesWaiting;
/******/ 						blockingPromisesWaiting = [];
/******/ 						for (var i = 0; i < list.length; i++) {
/******/ 							list[i]();
/******/ 						}
/******/ 					}
/******/ 				});
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function trackBlockingPromise(promise) {
/******/ 			switch (currentStatus) {
/******/ 				case "ready":
/******/ 					setStatus("prepare");
/******/ 				/* fallthrough */
/******/ 				case "prepare":
/******/ 					blockingPromises++;
/******/ 					promise.then(unblock, unblock);
/******/ 					return promise;
/******/ 				default:
/******/ 					return promise;
/******/ 			}
/******/ 		}
/******/ 		
/******/ 		function waitForBlockingPromises(fn) {
/******/ 			if (blockingPromises === 0) return fn();
/******/ 			return new Promise(function (resolve) {
/******/ 				blockingPromisesWaiting.push(function () {
/******/ 					resolve(fn());
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function hotCheck(applyOnUpdate) {
/******/ 			if (currentStatus !== "idle") {
/******/ 				throw new Error("check() is only allowed in idle status");
/******/ 			}
/******/ 			return setStatus("check")
/******/ 				.then(__webpack_require__.hmrM)
/******/ 				.then(function (update) {
/******/ 					if (!update) {
/******/ 						return setStatus(applyInvalidatedModules() ? "ready" : "idle").then(
/******/ 							function () {
/******/ 								return null;
/******/ 							}
/******/ 						);
/******/ 					}
/******/ 		
/******/ 					return setStatus("prepare").then(function () {
/******/ 						var updatedModules = [];
/******/ 						currentUpdateApplyHandlers = [];
/******/ 		
/******/ 						return Promise.all(
/******/ 							Object.keys(__webpack_require__.hmrC).reduce(function (
/******/ 								promises,
/******/ 								key
/******/ 							) {
/******/ 								__webpack_require__.hmrC[key](
/******/ 									update.c,
/******/ 									update.r,
/******/ 									update.m,
/******/ 									promises,
/******/ 									currentUpdateApplyHandlers,
/******/ 									updatedModules
/******/ 								);
/******/ 								return promises;
/******/ 							},
/******/ 							[])
/******/ 						).then(function () {
/******/ 							return waitForBlockingPromises(function () {
/******/ 								if (applyOnUpdate) {
/******/ 									return internalApply(applyOnUpdate);
/******/ 								} else {
/******/ 									return setStatus("ready").then(function () {
/******/ 										return updatedModules;
/******/ 									});
/******/ 								}
/******/ 							});
/******/ 						});
/******/ 					});
/******/ 				});
/******/ 		}
/******/ 		
/******/ 		function hotApply(options) {
/******/ 			if (currentStatus !== "ready") {
/******/ 				return Promise.resolve().then(function () {
/******/ 					throw new Error(
/******/ 						"apply() is only allowed in ready status (state: " +
/******/ 							currentStatus +
/******/ 							")"
/******/ 					);
/******/ 				});
/******/ 			}
/******/ 			return internalApply(options);
/******/ 		}
/******/ 		
/******/ 		function internalApply(options) {
/******/ 			options = options || {};
/******/ 		
/******/ 			applyInvalidatedModules();
/******/ 		
/******/ 			var results = currentUpdateApplyHandlers.map(function (handler) {
/******/ 				return handler(options);
/******/ 			});
/******/ 			currentUpdateApplyHandlers = undefined;
/******/ 		
/******/ 			var errors = results
/******/ 				.map(function (r) {
/******/ 					return r.error;
/******/ 				})
/******/ 				.filter(Boolean);
/******/ 		
/******/ 			if (errors.length > 0) {
/******/ 				return setStatus("abort").then(function () {
/******/ 					throw errors[0];
/******/ 				});
/******/ 			}
/******/ 		
/******/ 			// Now in "dispose" phase
/******/ 			var disposePromise = setStatus("dispose");
/******/ 		
/******/ 			results.forEach(function (result) {
/******/ 				if (result.dispose) result.dispose();
/******/ 			});
/******/ 		
/******/ 			// Now in "apply" phase
/******/ 			var applyPromise = setStatus("apply");
/******/ 		
/******/ 			var error;
/******/ 			var reportError = function (err) {
/******/ 				if (!error) error = err;
/******/ 			};
/******/ 		
/******/ 			var outdatedModules = [];
/******/ 			results.forEach(function (result) {
/******/ 				if (result.apply) {
/******/ 					var modules = result.apply(reportError);
/******/ 					if (modules) {
/******/ 						for (var i = 0; i < modules.length; i++) {
/******/ 							outdatedModules.push(modules[i]);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 			});
/******/ 		
/******/ 			return Promise.all([disposePromise, applyPromise]).then(function () {
/******/ 				// handle errors in accept handlers and self accepted module load
/******/ 				if (error) {
/******/ 					return setStatus("fail").then(function () {
/******/ 						throw error;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				if (queuedInvalidatedModules) {
/******/ 					return internalApply(options).then(function (list) {
/******/ 						outdatedModules.forEach(function (moduleId) {
/******/ 							if (list.indexOf(moduleId) < 0) list.push(moduleId);
/******/ 						});
/******/ 						return list;
/******/ 					});
/******/ 				}
/******/ 		
/******/ 				return setStatus("idle").then(function () {
/******/ 					return outdatedModules;
/******/ 				});
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		function applyInvalidatedModules() {
/******/ 			if (queuedInvalidatedModules) {
/******/ 				if (!currentUpdateApplyHandlers) currentUpdateApplyHandlers = [];
/******/ 				Object.keys(__webpack_require__.hmrI).forEach(function (key) {
/******/ 					queuedInvalidatedModules.forEach(function (moduleId) {
/******/ 						__webpack_require__.hmrI[key](
/******/ 							moduleId,
/******/ 							currentUpdateApplyHandlers
/******/ 						);
/******/ 					});
/******/ 				});
/******/ 				queuedInvalidatedModules = undefined;
/******/ 				return true;
/******/ 			}
/******/ 		}
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "/";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = __webpack_require__.hmrS_jsonp = __webpack_require__.hmrS_jsonp || {
/******/ 			"background.js": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		var currentUpdatedModulesList;
/******/ 		var waitingUpdateResolves = {};
/******/ 		function loadUpdateChunk(chunkId, updatedModulesList) {
/******/ 			currentUpdatedModulesList = updatedModulesList;
/******/ 			return new Promise((resolve, reject) => {
/******/ 				waitingUpdateResolves[chunkId] = resolve;
/******/ 				// start update chunk loading
/******/ 				var url = __webpack_require__.p + __webpack_require__.hu(chunkId);
/******/ 				// create error before stack unwound to get useful stacktrace later
/******/ 				var error = new Error();
/******/ 				var loadingEnded = (event) => {
/******/ 					if(waitingUpdateResolves[chunkId]) {
/******/ 						waitingUpdateResolves[chunkId] = undefined
/******/ 						var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 						var realSrc = event && event.target && event.target.src;
/******/ 						error.message = 'Loading hot update chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 						error.name = 'ChunkLoadError';
/******/ 						error.type = errorType;
/******/ 						error.request = realSrc;
/******/ 						reject(error);
/******/ 					}
/******/ 				};
/******/ 				__webpack_require__.l(url, loadingEnded);
/******/ 			});
/******/ 		}
/******/ 		
/******/ 		self["webpackHotUpdateoakley"] = (chunkId, moreModules, runtime) => {
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					currentUpdate[moduleId] = moreModules[moduleId];
/******/ 					if(currentUpdatedModulesList) currentUpdatedModulesList.push(moduleId);
/******/ 				}
/******/ 			}
/******/ 			if(runtime) currentUpdateRuntime.push(runtime);
/******/ 			if(waitingUpdateResolves[chunkId]) {
/******/ 				waitingUpdateResolves[chunkId]();
/******/ 				waitingUpdateResolves[chunkId] = undefined;
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		var currentUpdateChunks;
/******/ 		var currentUpdate;
/******/ 		var currentUpdateRemovedChunks;
/******/ 		var currentUpdateRuntime;
/******/ 		function applyHandler(options) {
/******/ 			if (__webpack_require__.f) delete __webpack_require__.f.jsonpHmr;
/******/ 			currentUpdateChunks = undefined;
/******/ 			function getAffectedModuleEffects(updateModuleId) {
/******/ 				var outdatedModules = [updateModuleId];
/******/ 				var outdatedDependencies = {};
/******/ 		
/******/ 				var queue = outdatedModules.map(function (id) {
/******/ 					return {
/******/ 						chain: [id],
/******/ 						id: id
/******/ 					};
/******/ 				});
/******/ 				while (queue.length > 0) {
/******/ 					var queueItem = queue.pop();
/******/ 					var moduleId = queueItem.id;
/******/ 					var chain = queueItem.chain;
/******/ 					var module = __webpack_require__.c[moduleId];
/******/ 					if (
/******/ 						!module ||
/******/ 						(module.hot._selfAccepted && !module.hot._selfInvalidated)
/******/ 					)
/******/ 						continue;
/******/ 					if (module.hot._selfDeclined) {
/******/ 						return {
/******/ 							type: "self-declined",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					if (module.hot._main) {
/******/ 						return {
/******/ 							type: "unaccepted",
/******/ 							chain: chain,
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					for (var i = 0; i < module.parents.length; i++) {
/******/ 						var parentId = module.parents[i];
/******/ 						var parent = __webpack_require__.c[parentId];
/******/ 						if (!parent) continue;
/******/ 						if (parent.hot._declinedDependencies[moduleId]) {
/******/ 							return {
/******/ 								type: "declined",
/******/ 								chain: chain.concat([parentId]),
/******/ 								moduleId: moduleId,
/******/ 								parentId: parentId
/******/ 							};
/******/ 						}
/******/ 						if (outdatedModules.indexOf(parentId) !== -1) continue;
/******/ 						if (parent.hot._acceptedDependencies[moduleId]) {
/******/ 							if (!outdatedDependencies[parentId])
/******/ 								outdatedDependencies[parentId] = [];
/******/ 							addAllToSet(outdatedDependencies[parentId], [moduleId]);
/******/ 							continue;
/******/ 						}
/******/ 						delete outdatedDependencies[parentId];
/******/ 						outdatedModules.push(parentId);
/******/ 						queue.push({
/******/ 							chain: chain.concat([parentId]),
/******/ 							id: parentId
/******/ 						});
/******/ 					}
/******/ 				}
/******/ 		
/******/ 				return {
/******/ 					type: "accepted",
/******/ 					moduleId: updateModuleId,
/******/ 					outdatedModules: outdatedModules,
/******/ 					outdatedDependencies: outdatedDependencies
/******/ 				};
/******/ 			}
/******/ 		
/******/ 			function addAllToSet(a, b) {
/******/ 				for (var i = 0; i < b.length; i++) {
/******/ 					var item = b[i];
/******/ 					if (a.indexOf(item) === -1) a.push(item);
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			// at begin all updates modules are outdated
/******/ 			// the "outdated" status can propagate to parents if they don't accept the children
/******/ 			var outdatedDependencies = {};
/******/ 			var outdatedModules = [];
/******/ 			var appliedUpdate = {};
/******/ 		
/******/ 			var warnUnexpectedRequire = function warnUnexpectedRequire(module) {
/******/ 				console.warn(
/******/ 					"[HMR] unexpected require(" + module.id + ") to disposed module"
/******/ 				);
/******/ 			};
/******/ 		
/******/ 			for (var moduleId in currentUpdate) {
/******/ 				if (__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 					var newModuleFactory = currentUpdate[moduleId];
/******/ 					/** @type {TODO} */
/******/ 					var result;
/******/ 					if (newModuleFactory) {
/******/ 						result = getAffectedModuleEffects(moduleId);
/******/ 					} else {
/******/ 						result = {
/******/ 							type: "disposed",
/******/ 							moduleId: moduleId
/******/ 						};
/******/ 					}
/******/ 					/** @type {Error|false} */
/******/ 					var abortError = false;
/******/ 					var doApply = false;
/******/ 					var doDispose = false;
/******/ 					var chainInfo = "";
/******/ 					if (result.chain) {
/******/ 						chainInfo = "\nUpdate propagation: " + result.chain.join(" -> ");
/******/ 					}
/******/ 					switch (result.type) {
/******/ 						case "self-declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of self decline: " +
/******/ 										result.moduleId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "declined":
/******/ 							if (options.onDeclined) options.onDeclined(result);
/******/ 							if (!options.ignoreDeclined)
/******/ 								abortError = new Error(
/******/ 									"Aborted because of declined dependency: " +
/******/ 										result.moduleId +
/******/ 										" in " +
/******/ 										result.parentId +
/******/ 										chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "unaccepted":
/******/ 							if (options.onUnaccepted) options.onUnaccepted(result);
/******/ 							if (!options.ignoreUnaccepted)
/******/ 								abortError = new Error(
/******/ 									"Aborted because " + moduleId + " is not accepted" + chainInfo
/******/ 								);
/******/ 							break;
/******/ 						case "accepted":
/******/ 							if (options.onAccepted) options.onAccepted(result);
/******/ 							doApply = true;
/******/ 							break;
/******/ 						case "disposed":
/******/ 							if (options.onDisposed) options.onDisposed(result);
/******/ 							doDispose = true;
/******/ 							break;
/******/ 						default:
/******/ 							throw new Error("Unexception type " + result.type);
/******/ 					}
/******/ 					if (abortError) {
/******/ 						return {
/******/ 							error: abortError
/******/ 						};
/******/ 					}
/******/ 					if (doApply) {
/******/ 						appliedUpdate[moduleId] = newModuleFactory;
/******/ 						addAllToSet(outdatedModules, result.outdatedModules);
/******/ 						for (moduleId in result.outdatedDependencies) {
/******/ 							if (__webpack_require__.o(result.outdatedDependencies, moduleId)) {
/******/ 								if (!outdatedDependencies[moduleId])
/******/ 									outdatedDependencies[moduleId] = [];
/******/ 								addAllToSet(
/******/ 									outdatedDependencies[moduleId],
/******/ 									result.outdatedDependencies[moduleId]
/******/ 								);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 					if (doDispose) {
/******/ 						addAllToSet(outdatedModules, [result.moduleId]);
/******/ 						appliedUpdate[moduleId] = warnUnexpectedRequire;
/******/ 					}
/******/ 				}
/******/ 			}
/******/ 			currentUpdate = undefined;
/******/ 		
/******/ 			// Store self accepted outdated modules to require them later by the module system
/******/ 			var outdatedSelfAcceptedModules = [];
/******/ 			for (var j = 0; j < outdatedModules.length; j++) {
/******/ 				var outdatedModuleId = outdatedModules[j];
/******/ 				var module = __webpack_require__.c[outdatedModuleId];
/******/ 				if (
/******/ 					module &&
/******/ 					(module.hot._selfAccepted || module.hot._main) &&
/******/ 					// removed self-accepted modules should not be required
/******/ 					appliedUpdate[outdatedModuleId] !== warnUnexpectedRequire &&
/******/ 					// when called invalidate self-accepting is not possible
/******/ 					!module.hot._selfInvalidated
/******/ 				) {
/******/ 					outdatedSelfAcceptedModules.push({
/******/ 						module: outdatedModuleId,
/******/ 						require: module.hot._requireSelf,
/******/ 						errorHandler: module.hot._selfAccepted
/******/ 					});
/******/ 				}
/******/ 			}
/******/ 		
/******/ 			var moduleOutdatedDependencies;
/******/ 		
/******/ 			return {
/******/ 				dispose: function () {
/******/ 					currentUpdateRemovedChunks.forEach(function (chunkId) {
/******/ 						delete installedChunks[chunkId];
/******/ 					});
/******/ 					currentUpdateRemovedChunks = undefined;
/******/ 		
/******/ 					var idx;
/******/ 					var queue = outdatedModules.slice();
/******/ 					while (queue.length > 0) {
/******/ 						var moduleId = queue.pop();
/******/ 						var module = __webpack_require__.c[moduleId];
/******/ 						if (!module) continue;
/******/ 		
/******/ 						var data = {};
/******/ 		
/******/ 						// Call dispose handlers
/******/ 						var disposeHandlers = module.hot._disposeHandlers;
/******/ 						for (j = 0; j < disposeHandlers.length; j++) {
/******/ 							disposeHandlers[j].call(null, data);
/******/ 						}
/******/ 						__webpack_require__.hmrD[moduleId] = data;
/******/ 		
/******/ 						// disable module (this disables requires from this module)
/******/ 						module.hot.active = false;
/******/ 		
/******/ 						// remove module from cache
/******/ 						delete __webpack_require__.c[moduleId];
/******/ 		
/******/ 						// when disposing there is no need to call dispose handler
/******/ 						delete outdatedDependencies[moduleId];
/******/ 		
/******/ 						// remove "parents" references from all children
/******/ 						for (j = 0; j < module.children.length; j++) {
/******/ 							var child = __webpack_require__.c[module.children[j]];
/******/ 							if (!child) continue;
/******/ 							idx = child.parents.indexOf(moduleId);
/******/ 							if (idx >= 0) {
/******/ 								child.parents.splice(idx, 1);
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// remove outdated dependency from module children
/******/ 					var dependency;
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								for (j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									dependency = moduleOutdatedDependencies[j];
/******/ 									idx = module.children.indexOf(dependency);
/******/ 									if (idx >= 0) module.children.splice(idx, 1);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 				},
/******/ 				apply: function (reportError) {
/******/ 					// insert new code
/******/ 					for (var updateModuleId in appliedUpdate) {
/******/ 						if (__webpack_require__.o(appliedUpdate, updateModuleId)) {
/******/ 							__webpack_require__.m[updateModuleId] = appliedUpdate[updateModuleId];
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// run new runtime modules
/******/ 					for (var i = 0; i < currentUpdateRuntime.length; i++) {
/******/ 						currentUpdateRuntime[i](__webpack_require__);
/******/ 					}
/******/ 		
/******/ 					// call accept handlers
/******/ 					for (var outdatedModuleId in outdatedDependencies) {
/******/ 						if (__webpack_require__.o(outdatedDependencies, outdatedModuleId)) {
/******/ 							var module = __webpack_require__.c[outdatedModuleId];
/******/ 							if (module) {
/******/ 								moduleOutdatedDependencies =
/******/ 									outdatedDependencies[outdatedModuleId];
/******/ 								var callbacks = [];
/******/ 								var errorHandlers = [];
/******/ 								var dependenciesForCallbacks = [];
/******/ 								for (var j = 0; j < moduleOutdatedDependencies.length; j++) {
/******/ 									var dependency = moduleOutdatedDependencies[j];
/******/ 									var acceptCallback =
/******/ 										module.hot._acceptedDependencies[dependency];
/******/ 									var errorHandler =
/******/ 										module.hot._acceptedErrorHandlers[dependency];
/******/ 									if (acceptCallback) {
/******/ 										if (callbacks.indexOf(acceptCallback) !== -1) continue;
/******/ 										callbacks.push(acceptCallback);
/******/ 										errorHandlers.push(errorHandler);
/******/ 										dependenciesForCallbacks.push(dependency);
/******/ 									}
/******/ 								}
/******/ 								for (var k = 0; k < callbacks.length; k++) {
/******/ 									try {
/******/ 										callbacks[k].call(null, moduleOutdatedDependencies);
/******/ 									} catch (err) {
/******/ 										if (typeof errorHandlers[k] === "function") {
/******/ 											try {
/******/ 												errorHandlers[k](err, {
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k]
/******/ 												});
/******/ 											} catch (err2) {
/******/ 												if (options.onErrored) {
/******/ 													options.onErrored({
/******/ 														type: "accept-error-handler-errored",
/******/ 														moduleId: outdatedModuleId,
/******/ 														dependencyId: dependenciesForCallbacks[k],
/******/ 														error: err2,
/******/ 														originalError: err
/******/ 													});
/******/ 												}
/******/ 												if (!options.ignoreErrored) {
/******/ 													reportError(err2);
/******/ 													reportError(err);
/******/ 												}
/******/ 											}
/******/ 										} else {
/******/ 											if (options.onErrored) {
/******/ 												options.onErrored({
/******/ 													type: "accept-errored",
/******/ 													moduleId: outdatedModuleId,
/******/ 													dependencyId: dependenciesForCallbacks[k],
/******/ 													error: err
/******/ 												});
/******/ 											}
/******/ 											if (!options.ignoreErrored) {
/******/ 												reportError(err);
/******/ 											}
/******/ 										}
/******/ 									}
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					// Load self accepted modules
/******/ 					for (var o = 0; o < outdatedSelfAcceptedModules.length; o++) {
/******/ 						var item = outdatedSelfAcceptedModules[o];
/******/ 						var moduleId = item.module;
/******/ 						try {
/******/ 							item.require(moduleId);
/******/ 						} catch (err) {
/******/ 							if (typeof item.errorHandler === "function") {
/******/ 								try {
/******/ 									item.errorHandler(err, {
/******/ 										moduleId: moduleId,
/******/ 										module: __webpack_require__.c[moduleId]
/******/ 									});
/******/ 								} catch (err2) {
/******/ 									if (options.onErrored) {
/******/ 										options.onErrored({
/******/ 											type: "self-accept-error-handler-errored",
/******/ 											moduleId: moduleId,
/******/ 											error: err2,
/******/ 											originalError: err
/******/ 										});
/******/ 									}
/******/ 									if (!options.ignoreErrored) {
/******/ 										reportError(err2);
/******/ 										reportError(err);
/******/ 									}
/******/ 								}
/******/ 							} else {
/******/ 								if (options.onErrored) {
/******/ 									options.onErrored({
/******/ 										type: "self-accept-errored",
/******/ 										moduleId: moduleId,
/******/ 										error: err
/******/ 									});
/******/ 								}
/******/ 								if (!options.ignoreErrored) {
/******/ 									reportError(err);
/******/ 								}
/******/ 							}
/******/ 						}
/******/ 					}
/******/ 		
/******/ 					return outdatedModules;
/******/ 				}
/******/ 			};
/******/ 		}
/******/ 		__webpack_require__.hmrI.jsonp = function (moduleId, applyHandlers) {
/******/ 			if (!currentUpdate) {
/******/ 				currentUpdate = {};
/******/ 				currentUpdateRuntime = [];
/******/ 				currentUpdateRemovedChunks = [];
/******/ 				applyHandlers.push(applyHandler);
/******/ 			}
/******/ 			if (!__webpack_require__.o(currentUpdate, moduleId)) {
/******/ 				currentUpdate[moduleId] = __webpack_require__.m[moduleId];
/******/ 			}
/******/ 		};
/******/ 		__webpack_require__.hmrC.jsonp = function (
/******/ 			chunkIds,
/******/ 			removedChunks,
/******/ 			removedModules,
/******/ 			promises,
/******/ 			applyHandlers,
/******/ 			updatedModulesList
/******/ 		) {
/******/ 			applyHandlers.push(applyHandler);
/******/ 			currentUpdateChunks = {};
/******/ 			currentUpdateRemovedChunks = removedChunks;
/******/ 			currentUpdate = removedModules.reduce(function (obj, key) {
/******/ 				obj[key] = false;
/******/ 				return obj;
/******/ 			}, {});
/******/ 			currentUpdateRuntime = [];
/******/ 			chunkIds.forEach(function (chunkId) {
/******/ 				if (
/******/ 					__webpack_require__.o(installedChunks, chunkId) &&
/******/ 					installedChunks[chunkId] !== undefined
/******/ 				) {
/******/ 					promises.push(loadUpdateChunk(chunkId, updatedModulesList));
/******/ 					currentUpdateChunks[chunkId] = true;
/******/ 				} else {
/******/ 					currentUpdateChunks[chunkId] = false;
/******/ 				}
/******/ 			});
/******/ 			if (__webpack_require__.f) {
/******/ 				__webpack_require__.f.jsonpHmr = function (chunkId, promises) {
/******/ 					if (
/******/ 						currentUpdateChunks &&
/******/ 						__webpack_require__.o(currentUpdateChunks, chunkId) &&
/******/ 						!currentUpdateChunks[chunkId]
/******/ 					) {
/******/ 						promises.push(loadUpdateChunk(chunkId));
/******/ 						currentUpdateChunks[chunkId] = true;
/******/ 					}
/******/ 				};
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.hmrM = () => {
/******/ 			if (typeof fetch === "undefined") throw new Error("No browser support: need fetch API");
/******/ 			return fetch(__webpack_require__.p + __webpack_require__.hmrF()).then((response) => {
/******/ 				if(response.status === 404) return; // no update available
/******/ 				if(!response.ok) throw new Error("Failed to fetch update manifest " + response.statusText);
/******/ 				return response.json();
/******/ 			});
/******/ 		};
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// no jsonp function
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// module cache are used so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	var __webpack_exports__ = __webpack_require__("./app/scripts/background.js");
/******/ 	
/******/ })()
;
//# sourceMappingURL=background.js.map